# -*- coding: utf-8 -*-
"""
BRIGADA 2030: EL POZO DEL TIEMPO
TecNM / ITS de Irapuato - Track Talents 2026 - Reto JAPAMI

Este es el archivo que ARRANCA el juego.
Para jugar:   py main.py        (o doble clic en JUGAR.bat)

Lo unico que hace este archivo es:
  1. Abrir la ventana.
  2. Llevar la cuenta de en que pantalla estamos.
  3. Repetir 60 veces por segundo: leer teclas -> actualizar -> dibujar.

El recorrido completo del juego es:

  titulo -> elegir personaje -> instrucciones
         -> NIVEL 1  (el pueblo seco, pelea con Corvo en el pozo)
         -> viaje al futuro
         -> NIVEL 2  (el 2030 arrasado, el jefe de basura)
         -> viaje de regreso
         -> NIVEL 3  (la planta de la H2O Company, el jefe final)
         -> despedida de Corvo + creditos
"""
import asyncio
import sys

import pygame

from juego import ajustes as cfg
from juego import recursos
from juego.nivel import NivelBase
from juego.tactil import Tactil, TeclasCombinadas
from juego.nivel1 import Nivel1
from juego.nivel2 import Nivel2
from juego.nivel3 import Nivel3
from juego.pantallas import (Titulo, ElegirPersonaje, Instrucciones,
                             Transicion, FinDeNivel, Final)


# Lo que el juego tiene que recordar entre pantalla y pantalla.
estado = {
    "personaje": "aqua",     # a quien eligio el jugador
    "nivel": "nivel1",       # en que nivel va (para reintentar el correcto)
}


def crear_pantalla(nombre, anterior=None):
    """Devuelve el objeto de la pantalla que toca mostrar."""
    if nombre == "titulo":
        return Titulo()

    if nombre == "personaje":
        return ElegirPersonaje()

    if nombre == "tutorial":
        # venimos de la seleccion: nos quedamos con el personaje elegido
        if isinstance(anterior, ElegirPersonaje) and anterior.elegido:
            estado["personaje"] = anterior.elegido
        return Instrucciones()

    if nombre == "nivel1":
        estado["nivel"] = "nivel1"
        return Nivel1(estado["personaje"])

    if nombre == "transicion":
        return Transicion(estado["personaje"], "nivel2", al_futuro=True)

    if nombre == "nivel2":
        estado["nivel"] = "nivel2"
        return Nivel2(estado["personaje"])

    if nombre == "regreso":
        return Transicion(estado["personaje"], "nivel3", al_futuro=False)

    if nombre == "nivel3":
        estado["nivel"] = "nivel3"
        return Nivel3(estado["personaje"])

    if nombre == "final":
        return Final(estado["personaje"])

    if nombre == "fin":
        return FinDeNivel(anterior.resultado == "ganado",
                          anterior.jugador.gotas,
                          anterior.total_gotas,
                          estado["nivel"])

    raise ValueError("Pantalla desconocida: %s" % nombre)


def siguiente_tras_el_nivel(nivel):
    """Al terminar un nivel, a donde se va."""
    if nivel.resultado != "ganado":
        return "fin"                      # perdiste: pantalla de derrota
    if estado["nivel"] == "nivel1":
        return "transicion"               # viaje al futuro
    if estado["nivel"] == "nivel2":
        return "regreso"                  # Corvo te saca del 2030
    return "final"                        # ganaste el 3: despedida y creditos


def pantalla_de_carga(ventana):
    """
    El video de inicio son 120 imagenes y tarda un segundo en cargar.
    Mostramos un aviso para que no parezca que el juego se trabo.
    """
    ventana.fill(cfg.NEGRO)
    recursos.texto(ventana, "BRIGADA 2030", cfg.ANCHO // 2, cfg.ALTO // 2 - 60,
                   tamano=56, color=cfg.AGUA, centrado=True, negrita=True)
    recursos.texto(ventana, "Cargando...", cfg.ANCHO // 2, cfg.ALTO // 2 + 20,
                   tamano=24, color=cfg.BLANCO, centrado=True)
    pygame.display.flip()


WEB = sys.platform == "emscripten"      # True cuando corre en el navegador


def en_charla(pantalla):
    """En un nivel, ¿hay un dialogo abierto o una escena automatica?"""
    charla = getattr(pantalla, "dialogo_final", None) or getattr(pantalla, "dialogo", None)
    return bool((charla and charla.activo) or getattr(pantalla, "cinematica", False))


async def main():
    pygame.init()
    try:
        pygame.mixer.init()
    except pygame.error:
        print("Aviso: no se pudo iniciar el audio. El juego corre sin música.")

    ventana = pygame.display.set_mode((cfg.ANCHO, cfg.ALTO))
    pygame.display.set_caption(cfg.TITULO)
    reloj = pygame.time.Clock()

    pantalla_de_carga(ventana)
    await asyncio.sleep(0)
    pantalla = crear_pantalla("titulo")
    tactil = Tactil()

    def mandar_tecla(tecla):
        """Le pasa una tecla (real o del boton tactil) a la pantalla actual."""
        nonlocal pantalla
        siguiente = pantalla.tecla(tecla)
        if siguiente:
            pantalla = crear_pantalla(siguiente, pantalla)

    def toque_suelto(pos):
        """Un dedo toco la pantalla pero no un boton."""
        nonlocal pantalla
        es_nivel = isinstance(pantalla, NivelBase)
        if es_nivel:
            if en_charla(pantalla):
                mandar_tecla(pygame.K_SPACE)       # pasar el dialogo
            return
        responder = getattr(pantalla, "raton", None)
        if responder is not None:
            siguiente = responder(pos)
            if siguiente:
                pantalla = crear_pantalla(siguiente, pantalla)
                return
        mandar_tecla(pygame.K_SPACE)               # "toca para continuar"

    while True:
        es_nivel = isinstance(pantalla, NivelBase)
        tactil.elegir_botones(pantalla, es_nivel)
        tactil.oculto = es_nivel and en_charla(pantalla)

        # ---- 1. eventos (teclas, dedos, cerrar ventana) ----
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                if not WEB:
                    pygame.quit()
                    sys.exit()
            elif evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_ESCAPE and not WEB:
                    pygame.quit()
                    sys.exit()
                mandar_tecla(evento.key)

            # --- dedos en la pantalla del celular ---
            elif evento.type == pygame.FINGERDOWN:
                pos = tactil.a_pantalla(evento)
                teclas = None if tactil.oculto else tactil.dedo_abajo(evento.finger_id, pos)
                tactil.activo = True
                if teclas is None:
                    toque_suelto(pos)
                else:
                    for t in teclas:
                        mandar_tecla(t)
            elif evento.type == pygame.FINGERMOTION:
                for t in tactil.dedo_mueve(evento.finger_id, tactil.a_pantalla(evento)):
                    mandar_tecla(t)
            elif evento.type == pygame.FINGERUP:
                tactil.dedo_arriba(evento.finger_id)

            # clic del raton (en la compu). Los toques del celular tambien
            # llegan como "clic falso"; esos se ignoran porque ya se
            # atendieron arriba como dedos.
            elif evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
                if getattr(evento, "touch", False):
                    continue
                responder = getattr(pantalla, "raton", None)
                if responder is not None:
                    siguiente = responder(evento.pos)
                    if siguiente:
                        pantalla = crear_pantalla(siguiente, pantalla)

            elif evento.type in (pygame.WINDOWFOCUSLOST, pygame.WINDOWHIDDEN):
                tactil.soltar_todo()               # que no se quede caminando solo

        # ---- 2. actualizar ----
        if isinstance(pantalla, NivelBase):
            teclas = TeclasCombinadas(pygame.key.get_pressed(), tactil.presionadas())
            pantalla.actualizar(teclas)
            if pantalla.terminado:
                pantalla = crear_pantalla(siguiente_tras_el_nivel(pantalla), pantalla)
        else:
            siguiente = pantalla.actualizar()
            if siguiente:
                pantalla = crear_pantalla(siguiente, pantalla)

        # ---- 3. dibujar ----
        pantalla.dibujar(ventana)
        if not tactil.oculto:
            tactil.dibujar(ventana)
        pygame.display.flip()
        reloj.tick(cfg.FPS)
        await asyncio.sleep(0)          # el navegador necesita este respiro


if __name__ == "__main__":
    asyncio.run(main())
