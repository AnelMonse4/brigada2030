# -*- coding: utf-8 -*-
"""
Carga las imagenes, la musica y las letras.

Todo se carga UNA sola vez al arrancar y se guarda en memoria, para que el
juego no se trabe a media partida leyendo del disco.
"""
import os
import re
import glob

import pygame

from .ajustes import ASSETS, BLANCO, ANCHO, ALTO


_imagenes = {}
_animaciones = {}
_letras = {}


# ---------------------------------------------------------------------------
# Imagenes sueltas
# ---------------------------------------------------------------------------
def imagen(carpeta, nombre):
    """Devuelve la imagen assets/<carpeta>/<nombre>.png"""
    clave = (carpeta, nombre)
    if clave not in _imagenes:
        ruta = os.path.join(ASSETS, carpeta, nombre + ".png")
        img = pygame.image.load(ruta).convert_alpha()
        # Los fondos que no tienen NADA transparente se guardan sin canal de
        # transparencia: asi se dibujan mucho mas rapido (importa en celular).
        ancho, alto = img.get_size()
        if ancho * alto >= 300 * 300 and                 pygame.mask.from_surface(img, 254).count() == ancho * alto:
            img = img.convert()
        _imagenes[clave] = img
    return _imagenes[clave]


def tenir(img, color, alfa):
    """
    Devuelve una copia de la imagen "vista a traves de" un velo de color,
    igual que si se le pusiera encima un vidrio de ese color con esa
    transparencia (0-255). Respeta las partes transparentes.
    """
    copia = img.copy()
    k = 255 - alfa
    copia.fill((k, k, k), special_flags=pygame.BLEND_RGB_MULT)
    copia.fill(tuple(int(c * alfa / 255) for c in color[:3]),
               special_flags=pygame.BLEND_RGB_ADD)
    return copia


def aplanar(img, color):
    """
    Pega una imagen con partes transparentes sobre un color liso y la deja
    sin transparencia. Sirve para fondos que siempre se dibujan encima de
    ese mismo color: se ve igual y se dibuja mucho mas rapido.
    """
    plana = pygame.Surface(img.get_size()).convert()
    plana.fill(color)
    plana.blit(img, (0, 0))
    return plana


def escalar(img, factor):
    ancho = max(1, int(img.get_width() * factor))
    alto = max(1, int(img.get_height() * factor))
    return pygame.transform.scale(img, (ancho, alto))


_bordes = {}


def borde_pisable(carpeta, nombre, filas=18):
    """
    Dice en que parte de la imagen hay piso de verdad para caminar.

    Algunas plataformas tienen el dibujo macizo solo en el centro y los lados
    son patas, sombra o aire. Si la caja de choque usara el ancho completo de
    la imagen, el personaje caminaria SOBRE LA NADA antes de caerse.

    Devuelve (izquierda, derecha) en pixeles dentro de la imagen, mirando
    unicamente las primeras filas de arriba, que son las que se pisan.
    """
    clave = (carpeta, nombre)
    if clave in _bordes:
        return _bordes[clave]

    img = imagen(carpeta, nombre)
    ancho, alto = img.get_size()
    izquierda, derecha = ancho, 0
    for y in range(min(filas, alto)):
        for x in range(ancho):
            if img.get_at((x, y))[3] > 40:
                if x < izquierda:
                    izquierda = x
                if x > derecha:
                    derecha = x
    if izquierda > derecha:          # arriba no habia nada opaco
        izquierda, derecha = 0, ancho - 1

    _bordes[clave] = (izquierda, derecha + 1)
    return _bordes[clave]


def caja_de_piso(carpeta, nombre, x, y, alto=300):
    """Caja de choque de una plataforma, ajustada a donde de verdad hay piso."""
    izquierda, derecha = borde_pisable(carpeta, nombre)
    return pygame.Rect(x + izquierda, y, derecha - izquierda, alto)


# ---------------------------------------------------------------------------
# Animaciones
#
# Cada animacion es simplemente una LISTA de imagenes que se van mostrando
# una tras otra. Aqui decimos que archivos forman cada animacion.
# ---------------------------------------------------------------------------
def _cargar(carpeta, patron, saltar=()):
    """
    Junta los cuadros de una accion, en orden.

    Solo acepta archivos del tipo  patron_01.png,  patron_02.png...
    Es importante que sea exacto: con una busqueda suelta, pedir
    "disparando" tambien se traia "disparando_proyectil_01", y la animacion
    salia con cuadros de mas.
    """
    exacto = re.compile(r"^" + re.escape(patron) + r"_\d+\.png$")
    cuadros = []
    for archivo in sorted(glob.glob(os.path.join(ASSETS, carpeta, "*.png"))):
        base = os.path.basename(archivo)
        if base in saltar or not exacto.match(base):
            continue
        cuadros.append(pygame.image.load(archivo).convert_alpha())
    return cuadros


# Algunos cuadros originales son en realidad el LETRERO del renglon de la hoja
# de contactos (dicen "SALTO", "CORRIENDO"...), no un dibujo. Se omiten.
_BASURA = {
    "aqua": ("salto_01.png", "salto_07.png", "salto_08.png",
             "reaccion_impacto_01.png"),
    "monstruo": ("corriendo_01.png", "lanzamiento_01.png", "lanzamiento_02.png"),
    "corvo": (),
}


# ---------------------------------------------------------------------------
# Los dos protagonistas se animan igual, pero sus archivos se llaman distinto.
# Aqui esta la equivalencia: accion del juego -> como se llaman sus archivos.
# ---------------------------------------------------------------------------
PROTAGONISTAS = {
    "aqua": {
        "nombre": "AQUA",
        "quieto": "idle_quieto",
        "caminar": "caminando",
        "correr": "corriendo",
        "agachar": "agachado",
        "saltar": "salto",
        "disparar": "disparando_bolas",
        "bola": "proyectiles_bola_cabello",
        # estas dos son cuadros sueltos, no una serie completa
        "golpe": ("reaccion_impacto_02", "reaccion_impacto_04", "reaccion_impacto_05"),
        "caido": ("reaccion_impacto_11",),
        "bola_cuadros": ("proyectiles_bola_cabello_01",
                         "proyectiles_bola_cabello_02",
                         "proyectiles_bola_cabello_03"),
    },
    "yani": {
        "nombre": "YANI",
        "quieto": "idle",
        "caminar": "caminando",
        "correr": "corriendo",
        "agachar": "agachado",
        "saltar": "saltando",
        "disparar": "disparando",
        "bola": "disparando_proyectil",
        "golpe": ("reaccion_impacto_01", "reaccion_impacto_02",
                  "reaccion_impacto_03"),
        "caido": ("muerte_derrota_01", "muerte_derrota_02", "muerte_derrota_03"),
        "bola_cuadros": ("disparando_proyectil_01",
                         "disparando_proyectil_02",
                         "disparando_proyectil_03"),
    },
}


def _cargar_protagonista(clave):
    mapa = PROTAGONISTAS[clave]
    basura = _BASURA.get(clave, ())
    return {
        "quieto": _cargar(clave, mapa["quieto"], basura),
        "caminar": _cargar(clave, mapa["caminar"], basura),
        "correr": _cargar(clave, mapa["correr"], basura),
        "agachar": _cargar(clave, mapa["agachar"], basura),
        "saltar": _cargar(clave, mapa["saltar"], basura),
        "disparar": _cargar(clave, mapa["disparar"], basura),
        "golpe": [imagen(clave, n) for n in mapa["golpe"]],
        "caido": [imagen(clave, n) for n in mapa["caido"]],
        "bola": [imagen(clave, n) for n in mapa["bola_cuadros"]],
    }


def animaciones():
    """Devuelve el diccionario con TODAS las animaciones del juego."""
    if _animaciones:
        return _animaciones

    for clave in PROTAGONISTAS:
        _animaciones[clave] = _cargar_protagonista(clave)

    # OJO con los cuadros de Corvo: de las seis acciones del dibujante,
    # SOLO "flap" y "wing_attack" lo muestran VOLANDO con las alas abiertas.
    # "idle", "move", "hit" y "defeat" lo muestran PARADO en el suelo.
    # Cuando Corvo acompana al protagonista tiene que ir volando siempre,
    # asi que solo se usan los de vuelo.
    _animaciones["corvo"] = {
        "volar": _cargar("corvo", "flap"),          # vuelo normal
        "ataque": _cargar("corvo", "wing_attack"),  # vuelo + ataque de agua
        # estos tres son de SUELO: solo para cuando Corvo es el jefe y cae
        "posado": _cargar("corvo", "idle"),
        "golpe": _cargar("corvo", "hit"),
        "derrota": _cargar("corvo", "defeat"),
    }

    # --- personajes del nivel 3 ---
    # Se traducen a los MISMOS nombres de accion que usa el resto del juego
    # (quieto, caminar, lanzar...), para que la clase Enemigo sirva igual
    # con el monstruo de basura y con el obrero de la planta.
    _animaciones["hazmat"] = {
        "quieto": _cargar("hazmat", "idle"),
        "caminar": _cargar("hazmat", "walk"),
        "correr": _cargar("hazmat", "walk"),
        "lanzar": _cargar("hazmat", "throw_polluted_water_trash"),
        "golpe": _cargar("hazmat", "hit"),
        "derrota": _cargar("hazmat", "defeat"),
    }

    # el policia de la empresa: en vez de agua, te lanza monedas y billetes
    _animaciones["policia"] = {
        "quieto": _cargar("policia", "idle"),
        "caminar": _cargar("policia", "walk"),
        "correr": _cargar("policia", "walk"),
        "lanzar": _cargar("policia", "throw"),
        "golpe": _cargar("policia", "hit"),
        "derrota": _cargar("policia", "defeat"),
    }
    # el robot rociador de quimicos
    _animaciones["robot"] = {
        "quieto": _cargar("robot", "idle"),
        "caminar": _cargar("robot", "move"),
        "correr": _cargar("robot", "move"),
        "lanzar": _cargar("robot", "spraying"),
        "golpe": _cargar("robot", "hit"),
        "derrota": _cargar("robot", "defeat"),
    }

    for clave in ("jefe_mascara", "jefe_sin_mascara"):
        _animaciones[clave] = {
            "quieto": _cargar(clave, "idle"),
            "caminar": _cargar(clave, "walk"),
            "correr": _cargar(clave, "walk"),
            "atacar": _cargar(clave, "attack"),
            "golpe": _cargar(clave, "hit"),
            "derrota": _cargar(clave, "defeat"),
        }
    # la mascara cayendose, y el llanto cuando ya no la trae
    _animaciones["jefe_mascara"]["romper"] = _cargar("jefe_mascara", "mask_break")
    _animaciones["jefe_sin_mascara"]["llorar"] = _cargar("jefe_sin_mascara", "cry")

    basura_monstruo = _BASURA["monstruo"]
    _animaciones["monstruo"] = {
        "quieto": _cargar("monstruo", "reposo"),
        "caminar": _cargar("monstruo", "caminando"),
        "correr": _cargar("monstruo", "corriendo", basura_monstruo),
        "lanzar": _cargar("monstruo", "carga_basura"),
        "defensa": _cargar("monstruo", "defensa_tapa"),
    }

    return _animaciones


# ---------------------------------------------------------------------------
# Video de la pantalla de inicio
#
# Pygame no reproduce archivos .mp4. Lo que hacemos es cargar las imagenes que
# saco herramientas/preparar_imagenes.py y pasarlas rapido, como un flipbook.
#
# Se guardan mas chicas (854x480) para no llenar la memoria, y se agrandan a
# pantalla completa SOLO cuando cambia el cuadro (12 veces por segundo),
# no en cada uno de los 60 dibujados por segundo.
# ---------------------------------------------------------------------------
_videos = {}


class Video:
    def __init__(self, carpeta, fps=12):
        self.cuadros = []
        for ruta in sorted(glob.glob(os.path.join(ASSETS, carpeta, "*.jpg"))):
            self.cuadros.append(pygame.image.load(ruta).convert())
        self.fps = fps
        self.tiempo = 0.0
        self.indice = -1
        self.grande = None

    @property
    def hay_video(self):
        return bool(self.cuadros)

    def actualizar(self, segundos):
        if not self.cuadros:
            return
        self.tiempo += segundos
        nuevo = int(self.tiempo * self.fps) % len(self.cuadros)
        if nuevo != self.indice:
            self.indice = nuevo
            self.grande = pygame.transform.smoothscale(self.cuadros[nuevo], (ANCHO, ALTO))

    def dibujar(self, pantalla):
        if self.grande is not None:
            pantalla.blit(self.grande, (0, 0))
            return True
        return False


def video(carpeta, fps=12):
    """Carga el video una sola vez y lo reutiliza."""
    if carpeta not in _videos:
        _videos[carpeta] = Video(carpeta, fps)
    return _videos[carpeta]


# ---------------------------------------------------------------------------
# Letras
# ---------------------------------------------------------------------------
_FUENTES = ["consolas", "couriernew", "lucidaconsole", "dejavusansmono"]


def letra(tamano, negrita=False):
    clave = (tamano, negrita)
    if clave not in _letras:
        nombre = pygame.font.match_font(",".join(_FUENTES)) or None
        _letras[clave] = pygame.font.Font(nombre, tamano)
        _letras[clave].set_bold(negrita)
    return _letras[clave]


def texto(superficie, mensaje, x, y, tamano=24, color=BLANCO,
          centrado=False, negrita=False, sombra=True):
    """Dibuja texto con un contorno oscuro para que se lea sobre cualquier fondo."""
    fuente = letra(tamano, negrita)
    img = fuente.render(mensaje, True, color)
    rect = img.get_rect()
    if centrado:
        rect.midtop = (x, y)
    else:
        rect.topleft = (x, y)
    if sombra:
        oscuro = fuente.render(mensaje, True, (8, 6, 12))
        for dx, dy in ((-2, 0), (2, 0), (0, -2), (0, 2)):
            superficie.blit(oscuro, (rect.x + dx, rect.y + dy))
    superficie.blit(img, rect)
    return rect


# ---------------------------------------------------------------------------
# Musica
# ---------------------------------------------------------------------------
_pista_actual = [None]


def musica(nombre, volumen=0.5):
    """Pone una pista. Si ya esta sonando esa misma, no hace nada."""
    if _pista_actual[0] == nombre:
        return
    ruta = os.path.join(ASSETS, "musica", nombre + ".ogg")
    if not os.path.exists(ruta):
        return
    try:
        pygame.mixer.music.load(ruta)
        pygame.mixer.music.set_volume(volumen)
        pygame.mixer.music.play(-1)
        _pista_actual[0] = nombre
    except pygame.error:
        _pista_actual[0] = None


def parar_musica():
    pygame.mixer.music.stop()
    _pista_actual[0] = None
