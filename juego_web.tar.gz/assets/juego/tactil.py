# -*- coding: utf-8 -*-
"""
CONTROLES TACTILES para jugar en el celular.

El juego original solo entiende teclas. Aqui dibujamos botones en la
pantalla y, cuando un dedo los toca, hacemos como si se hubiera
presionado la tecla correspondiente. Asi no hubo que cambiar nada de
como se mueve Aqua/Yani, ni de los niveles.

Se pueden tocar varios botones a la vez (por ejemplo correr a la derecha
y saltar al mismo tiempo): cada dedo se sigue por separado.
"""
import pygame

from . import ajustes as cfg


class Boton:
    def __init__(self, nombre, centro, radio, letrero, teclas, color):
        self.nombre = nombre
        self.centro = centro
        self.radio = radio
        self.letrero = letrero
        self.teclas = teclas          # teclas que "presiona" este boton
        self.color = color

    def toca(self, pos, margen=1.25):
        dx = pos[0] - self.centro[0]
        dy = pos[1] - self.centro[1]
        return dx * dx + dy * dy <= (self.radio * margen) ** 2


_A = 160   # transparencia de los botones


def _botones_nivel():
    abajo = cfg.ALTO - 95
    return [
        Boton("izq", (105, abajo), 62, "<", (pygame.K_LEFT,), (90, 190, 255)),
        Boton("der", (260, abajo), 62, ">", (pygame.K_RIGHT,), (90, 190, 255)),
        Boton("agachar", (182, abajo - 130), 44, "v", (pygame.K_DOWN,), (150, 150, 165)),
        Boton("correr", (cfg.ANCHO - 330, abajo + 20), 44, "CORRER",
              (pygame.K_LSHIFT,), (240, 190, 70)),
        Boton("disparar", (cfg.ANCHO - 215, abajo - 90), 58, "ATAQUE",
              (pygame.K_x,), (90, 190, 255)),
        Boton("saltar", (cfg.ANCHO - 100, abajo), 66, "SALTAR",
              (pygame.K_SPACE,), (120, 220, 60)),
    ]


def _botones_personaje():
    medio = cfg.ALTO // 2
    return [
        Boton("izq", (70, medio), 52, "<", (pygame.K_LEFT,), (90, 190, 255)),
        Boton("der", (cfg.ANCHO - 70, medio), 52, ">", (pygame.K_RIGHT,), (90, 190, 255)),
    ]


class Tactil:
    def __init__(self):
        self.activo = False          # se enciende con el primer toque
        self.dedos = {}              # id del dedo -> boton que esta tocando
        self.botones = []
        self.modo = None
        self.oculto = False
        self._letras = {}
        self._cache = {}

    # -- que botones mostrar segun la pantalla -------------------------
    def elegir_botones(self, pantalla, es_nivel):
        modo = "nivel" if es_nivel else type(pantalla).__name__
        if modo == self.modo:
            return
        self.modo = modo
        self.dedos.clear()
        if es_nivel:
            self.botones = _botones_nivel()
        elif modo == "ElegirPersonaje":
            self.botones = _botones_personaje()
        else:
            self.botones = []

    def _boton_en(self, pos):
        for b in self.botones:
            if b.toca(pos):
                return b
        return None

    # -- dedos ---------------------------------------------------------
    @staticmethod
    def a_pantalla(evento):
        """Los dedos llegan en 0..1; los pasamos a pixeles del juego."""
        return (int(evento.x * cfg.ANCHO), int(evento.y * cfg.ALTO))

    def dedo_abajo(self, dedo, pos):
        """
        Devuelve la lista de teclas que hay que "presionar" una vez,
        o None si el toque no cayo en ningun boton.
        """
        self.activo = True
        b = self._boton_en(pos)
        if b is None:
            return None
        self.dedos[dedo] = b
        return list(b.teclas)

    def dedo_mueve(self, dedo, pos):
        """Si el dedo se desliza de un boton a otro (de < a >), cambia."""
        if dedo not in self.dedos:
            return []
        b = self._boton_en(pos)
        if b is not None and b is not self.dedos[dedo]:
            self.dedos[dedo] = b
            return list(b.teclas)
        return []

    def dedo_arriba(self, dedo):
        self.dedos.pop(dedo, None)

    def soltar_todo(self):
        self.dedos.clear()

    def presionadas(self):
        teclas = set()
        for b in self.dedos.values():
            teclas.update(b.teclas)
        return teclas

    # -- dibujar -------------------------------------------------------
    def _letra(self, tamano):
        if tamano not in self._letras:
            self._letras[tamano] = pygame.font.Font(None, tamano)
            self._letras[tamano].set_bold(True)
        return self._letras[tamano]

    def _imagen_boton(self, b, apretado):
        """Dibuja el boton UNA vez y lo guarda (en celular cuesta dibujarlo)."""
        clave = (b.nombre, b.letrero, b.radio, apretado)
        if clave not in self._cache:
            r = b.radio
            capa = pygame.Surface((r * 2 + 4, r * 2 + 4), pygame.SRCALPHA)
            c = (r + 2, r + 2)
            pygame.draw.circle(capa, (*cfg.NEGRO, 215 if apretado else 95), c, r)
            pygame.draw.circle(capa, (*b.color, _A + 60 if apretado else _A), c, r, 4)
            centro = Boton(b.nombre, c, r, b.letrero, b.teclas, b.color)
            if b.letrero in ("<", ">", "v"):
                self._flecha(capa, centro)
            else:
                tam = 30 if len(b.letrero) <= 4 else 22
                img = self._letra(tam).render(b.letrero, True, (245, 245, 245))
                capa.blit(img, img.get_rect(center=c))
            self._cache[clave] = capa
        return self._cache[clave]

    def dibujar(self, superficie):
        if not self.activo or not self.botones:
            return
        apretados = set(id(b) for b in self.dedos.values())
        for b in self.botones:
            capa = self._imagen_boton(b, id(b) in apretados)
            superficie.blit(capa, (b.centro[0] - b.radio - 2, b.centro[1] - b.radio - 2))

    @staticmethod
    def _flecha(superficie, b):
        x, y = b.centro
        s = b.radio * 0.45
        if b.letrero == "<":
            pts = [(x - s, y), (x + s * 0.7, y - s), (x + s * 0.7, y + s)]
        elif b.letrero == ">":
            pts = [(x + s, y), (x - s * 0.7, y - s), (x - s * 0.7, y + s)]
        else:
            pts = [(x, y + s), (x - s, y - s * 0.7), (x + s, y - s * 0.7)]
        pygame.draw.polygon(superficie, (245, 245, 245), pts)


class TeclasCombinadas:
    """
    Se comporta igual que pygame.key.get_pressed(): teclas[K_LEFT] da
    True si se esta presionando la flecha del teclado O el boton tactil.
    """

    def __init__(self, reales, virtuales):
        self.reales = reales
        self.virtuales = virtuales

    def __getitem__(self, tecla):
        return bool(self.reales[tecla]) or tecla in self.virtuales
