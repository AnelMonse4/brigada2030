# -*- coding: utf-8 -*-
"""
Los personajes y objetos que se mueven: Aqua, Corvo, los enemigos de basura,
el jefe, las bolas que dispara Aqua y las gotas de agua.

Idea general:
  * Cada personaje tiene una CAJA (rect) invisible que es lo que choca con el
    escenario. Es mas angosta que el dibujo para que se sienta justo.
  * El dibujo se pinta encima de esa caja, apoyado en los pies.
"""
import math
import random

import pygame

from . import ajustes as cfg
from . import recursos


# ---------------------------------------------------------------------------
# Animacion: va pasando los cuadros de una lista
# ---------------------------------------------------------------------------
class Animacion:
    def __init__(self, cuadros, velocidad=6, repetir=True):
        self.cuadros = cuadros or []
        self.velocidad = velocidad      # cuantos cuadros de juego dura cada dibujo
        self.repetir = repetir
        self.tiempo = 0
        self.indice = 0

    def reiniciar(self):
        self.tiempo = 0
        self.indice = 0

    @property
    def termino(self):
        return (not self.repetir) and self.indice >= len(self.cuadros) - 1

    def actualizar(self):
        if len(self.cuadros) <= 1:
            return
        self.tiempo += 1
        if self.tiempo >= self.velocidad:
            self.tiempo = 0
            if self.indice < len(self.cuadros) - 1:
                self.indice += 1
            elif self.repetir:
                self.indice = 0

    @property
    def imagen(self):
        if not self.cuadros:
            return None
        return self.cuadros[min(self.indice, len(self.cuadros) - 1)]


class Actor:
    """Cosas comunes a todos: dibujarse apoyado en los pies y mirar a un lado."""

    def __init__(self, x, y, ancho, alto):
        self.rect = pygame.Rect(0, 0, ancho, alto)
        self.rect.midbottom = (x, y)
        self.vx = 0.0
        self.vy = 0.0
        self.mirando = 1              # 1 = derecha, -1 = izquierda
        self.en_suelo = False         # lo actualiza nivel.mover()
        self.animaciones = {}
        self.estado = "quieto"
        self.vivo = True

    def poner(self, estado, reiniciar=False):
        if estado not in self.animaciones:
            return
        if estado != self.estado:
            self.estado = estado
            self.animaciones[estado].reiniciar()
        elif reiniciar:
            self.animaciones[estado].reiniciar()

    @property
    def animacion(self):
        return self.animaciones.get(self.estado)

    def dibujar(self, pantalla, cx, cy=0, alfa=255):
        anim = self.animacion
        if anim is None or anim.imagen is None:
            return
        img = anim.imagen
        if self.mirando < 0:
            img = pygame.transform.flip(img, True, False)
        if alfa < 255:
            img = img.copy()
            img.set_alpha(alfa)
        x = self.rect.centerx - img.get_width() // 2 - cx
        y = self.rect.bottom - img.get_height() - cy
        pantalla.blit(img, (x, y))

    def _aura(self, pantalla, cx, cy, color, margen):
        """Mancha de color detras del personaje, para avisar algo al jugador."""
        halo = pygame.Surface((self.rect.width + margen,
                               self.rect.height + margen), pygame.SRCALPHA)
        pygame.draw.ellipse(halo, color, halo.get_rect())
        pantalla.blit(halo, (self.rect.centerx - halo.get_width() // 2 - cx,
                             self.rect.centery - halo.get_height() // 2 - cy))


# ---------------------------------------------------------------------------
# Aqua
# ---------------------------------------------------------------------------
class Jugador(Actor):
    def __init__(self, x, y, personaje="aqua"):
        super().__init__(x, y, cfg.ANCHO_JUGADOR, cfg.ALTO_JUGADOR)
        self.personaje = personaje
        self.nombre = recursos.PROTAGONISTAS[personaje]["nombre"]
        a = recursos.animaciones()[personaje]
        self.animaciones = {
            "quieto": Animacion(a["quieto"], 8),
            "caminar": Animacion(a["caminar"], 6),
            "correr": Animacion(a["correr"], 4),
            "agachar": Animacion(a["agachar"], 7),
            "saltar": Animacion(a["saltar"], 7, repetir=False),
            "disparar": Animacion(a["disparar"], 4, repetir=False),
            "golpe": Animacion(a["golpe"], 6, repetir=False),
            "caido": Animacion(a["caido"], 9, repetir=False),
        }
        self.cuadros_bola = a["bola"]
        self.vidas = cfg.VIDAS
        self.gotas = 0
        self.en_suelo = False
        self.agachado = False
        self.saltos = 0              # cuantos saltos lleva dados en el aire
        self.invulnerable = 0
        self.recarga = 0
        self.aturdido = 0
        self.derrotado = False
        # en las escenas finales no debe poder recibir dano NI parpadear
        self.intocable = False

    # -- caja de colision -----------------------------------------------
    def _ajustar_altura(self, agachar):
        if agachar == self.agachado:
            return
        abajo = self.rect.bottom
        self.rect.height = cfg.ALTO_AGACHADO if agachar else cfg.ALTO_JUGADOR
        self.rect.bottom = abajo
        self.agachado = agachar

    # -- control --------------------------------------------------------
    def controlar(self, teclas, nivel):
        if self.derrotado or self.aturdido > 0:
            self.vx = 0.0
            return None

        corriendo = teclas[pygame.K_LSHIFT] or teclas[pygame.K_RSHIFT]
        rapidez = cfg.VELOCIDAD_CORRER if corriendo else cfg.VELOCIDAD

        quiere_agachar = (teclas[pygame.K_DOWN] or teclas[pygame.K_s]) and self.en_suelo
        if quiere_agachar:
            self._ajustar_altura(True)
        elif self.agachado and not nivel.hay_techo(self.rect):
            self._ajustar_altura(False)

        # agachado tambien se avanza, pero despacio: hace falta para pasar
        # por debajo de las puas que cuelgan del techo
        if self.agachado:
            rapidez = cfg.VELOCIDAD_AGACHADO

        self.vx = 0.0
        if teclas[pygame.K_LEFT] or teclas[pygame.K_a]:
            self.vx = -rapidez
            self.mirando = -1
        if teclas[pygame.K_RIGHT] or teclas[pygame.K_d]:
            self.vx = rapidez
            self.mirando = 1

        return None

    def saltar(self):
        """
        Primer toque: salto normal.
        Segundo toque en el aire: DOBLE SALTO, un poco mas corto.
        Sirve para esquivar los ataques de los jefes.
        """
        if self.agachado or self.derrotado or self.aturdido > 0:
            return False
        if self.en_suelo:
            self.saltos = 1
            self.vy = -cfg.FUERZA_SALTO
            self.en_suelo = False
            self.poner("saltar", reiniciar=True)
            return True
        if self.saltos < cfg.SALTOS_MAXIMOS:
            self.saltos += 1
            self.vy = -cfg.FUERZA_SALTO_DOBLE
            self.poner("saltar", reiniciar=True)
            self.polvo_doble = 18        # chispas para que se note
            return True
        return False

    def disparar(self):
        if self.recarga > 0 or self.derrotado or self.aturdido > 0 or self.agachado:
            return None
        self.recarga = cfg.RECARGA_DISPARO
        self.poner("disparar", reiniciar=True)
        salida_x = self.rect.centerx + self.mirando * 34
        salida_y = self.rect.centery - 12
        return Bola(salida_x, salida_y, self.mirando, self.cuadros_bola)

    # -- dano -----------------------------------------------------------
    def recibir_dano(self, cantidad=1, empuje=0):
        if self.invulnerable > 0 or self.derrotado or self.intocable:
            return False
        self.vidas -= cantidad
        self.invulnerable = cfg.INVULNERABLE
        self.aturdido = 22
        self.vy = -7.0
        self.vx = empuje
        self.poner("golpe", reiniciar=True)
        if self.vidas <= 0:
            self.vidas = 0
            self.derrotado = True
            self.poner("caido", reiniciar=True)
        return True

    # -- cada cuadro ----------------------------------------------------
    def actualizar(self, nivel):
        if self.recarga > 0:
            self.recarga -= 1
        if self.invulnerable > 0:
            self.invulnerable -= 1
        if self.aturdido > 0:
            self.aturdido -= 1
            self.vx *= 0.9

        self.vy = min(self.vy + cfg.GRAVEDAD, cfg.CAIDA_MAXIMA)
        nivel.mover(self, self.vx, self.vy)
        if self.en_suelo:
            self.saltos = 0
        if getattr(self, "polvo_doble", 0) > 0:
            self.polvo_doble -= 1

        if not self.derrotado and self.aturdido <= 0:
            if not self.en_suelo:
                self.poner("saltar")
            elif self.agachado:
                self.poner("agachar")
                if abs(self.vx) > 0.2:
                    self.animacion.velocidad = 9
            elif self.estado == "disparar" and not self.animaciones["disparar"].termino:
                pass
            elif abs(self.vx) > cfg.VELOCIDAD + 0.5:
                self.poner("correr")
            elif abs(self.vx) > 0.2:
                self.poner("caminar")
            else:
                self.poner("quieto")

        anim = self.animacion
        if anim:
            anim.actualizar()

    def dibujar(self, pantalla, cx, cy=0, alfa=255):
        # destellito bajo los pies al hacer el doble salto
        if getattr(self, "polvo_doble", 0) > 0:
            fuerza = self.polvo_doble / 18.0
            anillo = pygame.Surface((90, 40), pygame.SRCALPHA)
            pygame.draw.ellipse(anillo, (170, 230, 255, int(160 * fuerza)),
                                anillo.get_rect(), 4)
            pantalla.blit(anillo, (self.rect.centerx - 45 - cx,
                                   self.rect.bottom - 20 - cy))
        # parpadea cuando es invulnerable
        if self.invulnerable > 0 and (self.invulnerable // 4) % 2 == 0:
            alfa = 90
        super().dibujar(pantalla, cx, cy, alfa)


# ---------------------------------------------------------------------------
# Corvo: acompana volando al jugador (no se controla, no recibe dano)
# ---------------------------------------------------------------------------
class Corvo(Actor):
    def __init__(self, x, y):
        super().__init__(x, y, 60, 60)
        a = recursos.animaciones()["corvo"]
        # Solo cuadros de VUELO: el acompanante nunca se posa en el suelo.
        # "rapido" es el mismo aleteo pero mas veloz, para cuando corre
        # a alcanzar al protagonista.
        self.animaciones = {
            "volar": Animacion(a["volar"], 5),
            "rapido": Animacion(a["volar"], 3),
            "ataque": Animacion(a["ataque"], 4),
        }
        self.estado = "volar"
        self.x = float(x)
        self.y = float(y)
        self.fase = 0.0
        self.escondido = False       # durante la pelea del nivel 1 no acompana
        self.llevando = False        # al final del nivel 2 carga al protagonista

    def actualizar(self, jugador):
        if self.escondido:
            return
        # se queda flotando detras y arriba del jugador
        destino_x = jugador.rect.centerx - jugador.mirando * 120
        destino_y = jugador.rect.top - 70

        self.x += (destino_x - self.x) * 0.055
        self.y += (destino_y - self.y) * 0.075
        self.fase += 0.07

        movimiento = destino_x - self.x
        if abs(movimiento) > 30:
            self.mirando = 1 if movimiento > 0 else -1
        else:
            self.mirando = jugador.mirando

        self.poner("rapido" if abs(movimiento) > 40 else "volar")
        flote = 7 * math.sin(self.fase)          # sube y baja suavemente
        self.rect.center = (int(self.x), int(self.y + flote))
        self.animacion.actualizar()

    def colocar(self, x, y):
        """Lo pone en un sitio concreto (se usa en las escenas finales)."""
        self.x = float(x)
        self.y = float(y)
        self.rect.center = (int(x), int(y))


# ---------------------------------------------------------------------------
# Bola de agua que dispara Aqua
# ---------------------------------------------------------------------------
class Bola:
    def __init__(self, x, y, direccion, cuadros):
        self.anim = Animacion(cuadros, 4)
        self.direccion = direccion
        self.rect = pygame.Rect(0, 0, 34, 34)
        self.rect.center = (x, y)
        self.recorrido = 0
        self.viva = True

    def actualizar(self, nivel):
        paso = cfg.VELOCIDAD_BOLA * self.direccion
        self.rect.x += paso
        self.recorrido += abs(paso)
        self.anim.actualizar()
        if self.recorrido > cfg.ALCANCE_BOLA or nivel.choca_con_solido(self.rect):
            self.viva = False

    def dibujar(self, pantalla, cx, cy=0):
        img = self.anim.imagen
        if img is None:
            return
        if self.direccion < 0:
            img = pygame.transform.flip(img, True, False)
        pantalla.blit(img, (self.rect.centerx - img.get_width() // 2 - cx,
                            self.rect.centery - img.get_height() // 2 - cy))


# ---------------------------------------------------------------------------
# Enemigo de basura que patrulla
# ---------------------------------------------------------------------------
class Enemigo(Actor):
    """
    Enemigo que patrulla (o persigue, si es jefe).

    'paquete' dice de que personaje saca los dibujos: "monstruo" para los
    botes de basura de los niveles 1 y 2, "hazmat" para los obreros de la
    planta del nivel 3. Los dos usan los mismos nombres de accion.
    """

    def __init__(self, x, y, izquierda, derecha, escala=1.0, vida=None,
                 jefe=False, paquete="monstruo", proyectil="basura_toxica",
                 es_persona=False):
        ancho = int(62 * escala)
        alto = int(104 * escala)
        super().__init__(x, y, ancho, alto)
        self.paquete = paquete
        self.proyectil = proyectil
        self.carpeta_proyectil = "nivel"
        self.escala_proyectil = 0.55
        # Las PERSONAS (obreros, policias) no "mueren": salen corriendo.
        # Solo las maquinas y los monstruos de basura caen derrotados.
        self.es_persona = es_persona
        self.huyendo = 0
        self.sin_contacto = False
        self.suelta_gotas = 2        # cuantas gotas deja al caer
        a = recursos.animaciones()[paquete]

        def preparar(cuadros):
            if escala == 1.0:
                return cuadros
            return [recursos.escalar(c, escala) for c in cuadros]

        self.animaciones = {
            "quieto": Animacion(preparar(a["quieto"]), 8),
            "caminar": Animacion(preparar(a["caminar"]), 6),
            "correr": Animacion(preparar(a["correr"]), 5),
            "lanzar": Animacion(preparar(a["lanzar"]), 5, repetir=False),
        }
        self.estado = "caminar"
        self.izquierda = izquierda
        self.derecha = derecha
        self.jefe = jefe
        self.vida_max = vida if vida is not None else cfg.VIDA_ENEMIGO
        self.vida = self.vida_max
        self.rapidez = cfg.VELOCIDAD_JEFE if jefe else cfg.VELOCIDAD_ENEMIGO
        self.mirando = -1
        self.parpadeo = 0
        self.despierto = True
        self.titulo = "JEFE DE BASURA"
        self.espera_lanzar = random.randint(120, 240)
        self.espera_salto = 0

    def recibir_dano(self, cantidad=1):
        if self.huyendo:
            return True
        self.vida -= cantidad
        self.parpadeo = 10
        if self.vida <= 0:
            self.vida = 0
            if self.es_persona:
                # no cae: se asusta y sale corriendo. Mientras huye ya no
                # lastima al tocarlo, solo quiere irse.
                self.huyendo = 150
                self.vida = 1
                self.sin_contacto = True
            else:
                self.vivo = False
        return self.vivo

    def ultimo_ataque(self):
        """
        Un ataque de despedida justo antes de caer.

        Asi ningun enemigo se desploma sin haber hecho nada: siempre alcanza
        a lanzar lo suyo, aunque sea una vez.
        """
        if self.estado == "lanzar" and not self.animaciones["lanzar"].termino:
            return None
        self.poner("lanzar", reiniciar=True)
        return BasuraVoladora(self.rect.centerx, self.rect.centery - 10,
                              self.mirando, imagen=self.proyectil,
                              escala=self.escala_proyectil,
                              carpeta=self.carpeta_proyectil)

    def actualizar(self, nivel, jugador):
        if not self.vivo:
            return None

        if self.parpadeo > 0:
            self.parpadeo -= 1

        # una persona derrotada corre en direccion contraria y se va
        if self.huyendo:
            self.huyendo -= 1
            # se aleja del jugador: si lo tiene a la izquierda, corre a la
            # derecha, y al reves
            lado = 1 if jugador.rect.centerx < self.rect.centerx else -1
            self.mirando = lado
            self.vx = cfg.VELOCIDAD_HUIDA * lado
            self.poner("correr")
            self.vy = min(self.vy + cfg.GRAVEDAD, cfg.CAIDA_MAXIMA)
            nivel.mover(self, self.vx, self.vy)
            self.animacion.actualizar()
            if self.huyendo <= 0:
                self.vivo = False        # ya se fue de la pantalla
            return None

        disparo = None
        if self.jefe:
            # El jefe PERSIGUE al jugador por donde sea, y brinca para
            # alcanzarlo: si el jugador se sube a una plataforma o si al
            # jefe se le acaba el piso de enfrente, salta.
            self.espera_lanzar -= 1
            objetivo = jugador.rect.centerx
            if abs(objetivo - self.rect.centerx) > 90:
                self.mirando = 1 if objetivo > self.rect.centerx else -1
                self.vx = self.rapidez * self.mirando
                self.poner("correr")
            else:
                self.vx = 0.0
                self.poner("quieto")

            if self.espera_salto > 0:
                self.espera_salto -= 1
            if self.en_suelo and self.espera_salto == 0:
                mas_arriba = jugador.rect.bottom < self.rect.bottom - 70
                adelante = self.rect.centerx + self.mirando * 90
                sin_piso = not nivel.hay_piso_en(adelante, self.rect.bottom)
                if mas_arriba or sin_piso:
                    self.vy = -cfg.FUERZA_SALTO_JEFE
                    self.en_suelo = False
                    self.espera_salto = 26

            if self.espera_lanzar <= 0:
                self.espera_lanzar = random.randint(90, 160)
                self.poner("lanzar", reiniciar=True)
                # lanza mas corto que antes: asi se le puede esquivar
                # tomando distancia en vez de tener que saltar siempre
                disparo = BasuraVoladora(self.rect.centerx, self.rect.centery - 10,
                                         self.mirando, imagen=self.proyectil,
                                         escala=self.escala_proyectil,
                                         carpeta=self.carpeta_proyectil,
                                         rapidez=cfg.ALCANCE_LANZAMIENTO_JEFE)
        else:
            # patrulla, y cada cierto rato lanza lo suyo si el jugador esta
            # enfrente y a tiro
            self.vx = self.rapidez * self.mirando
            if self.estado != "lanzar" or self.animaciones["lanzar"].termino:
                self.poner("caminar")
            self.espera_lanzar -= 1
            if self.espera_lanzar <= 0:
                self.espera_lanzar = random.randint(*cfg.ESPERA_ATAQUE_ENEMIGO)
                distancia = jugador.rect.centerx - self.rect.centerx
                de_frente = (distancia > 0) == (self.mirando > 0)
                if de_frente and abs(distancia) < cfg.ALCANCE_ATAQUE_ENEMIGO:
                    self.poner("lanzar", reiniciar=True)
                    disparo = BasuraVoladora(
                        self.rect.centerx, self.rect.centery - 10,
                        self.mirando, imagen=self.proyectil,
                        escala=self.escala_proyectil,
                        carpeta=self.carpeta_proyectil)

        self.vy = min(self.vy + cfg.GRAVEDAD, cfg.CAIDA_MAXIMA)
        nivel.mover(self, self.vx, self.vy)

        # rebota en los limites de su zona de patrulla
        if not self.jefe:
            if self.rect.left <= self.izquierda:
                self.rect.left = self.izquierda
                self.mirando = 1
            elif self.rect.right >= self.derecha:
                self.rect.right = self.derecha
                self.mirando = -1
        else:
            self.rect.left = max(self.rect.left, self.izquierda)
            self.rect.right = min(self.rect.right, self.derecha)

        self.animacion.actualizar()
        return disparo

    def dibujar(self, pantalla, cx, cy=0, alfa=255):
        if self.parpadeo > 0 and self.parpadeo % 4 < 2:
            alfa = 120
        super().dibujar(pantalla, cx, cy, alfa)


# ---------------------------------------------------------------------------
# Basura que lanza el jefe
# ---------------------------------------------------------------------------
class BasuraVoladora:
    """Cosa que lanza un enemigo: cae en arco y gira mientras vuela."""

    def __init__(self, x, y, direccion, imagen="basura_toxica", escala=0.55,
                 rapidez=7.0, altura=-5.5, carpeta="nivel"):
        self.img = recursos.escalar(recursos.imagen(carpeta, imagen), escala)
        self.rect = self.img.get_rect(center=(x, y))
        self.vx = rapidez * direccion
        self.vy = altura
        self.giro = 0.0
        self.viva = True

    def actualizar(self, nivel):
        self.vy = min(self.vy + 0.35, cfg.CAIDA_MAXIMA)
        self.rect.x += int(self.vx)
        self.rect.y += int(self.vy)
        self.giro = (self.giro - 7) % 360
        if self.rect.top > cfg.ALTO + 200 or nivel.choca_con_solido(self.rect):
            self.viva = False

    def dibujar(self, pantalla, cx, cy=0):
        img = pygame.transform.rotate(self.img, self.giro)
        pantalla.blit(img, (self.rect.centerx - img.get_width() // 2 - cx,
                            self.rect.centery - img.get_height() // 2 - cy))


# ---------------------------------------------------------------------------
# Gota de agua que se recolecta
# ---------------------------------------------------------------------------
class Gota:
    def __init__(self, x, y):
        self.img = recursos.imagen("nivel", "gota")
        self.rect = self.img.get_rect(center=(x, y))
        self.base_y = y
        self.fase = random.uniform(0, 6.28)
        self.viva = True

    def actualizar(self):
        self.fase += 0.08
        self.rect.centery = int(self.base_y + 7 * math.sin(self.fase))

    def dibujar(self, pantalla, cx, cy=0):
        pantalla.blit(self.img, (self.rect.x - cx, self.rect.y - cy))


# ---------------------------------------------------------------------------
# JEFE DEL NIVEL 1: Corvo
#
# No camina: VUELA. Se mantiene flotando enfrente del jugador y cada cierto
# rato hace una de dos cosas:
#   * PICADA: se lanza en diagonal hacia donde esta el jugador.
#   * PLUMAS: dispara tres gotas de agua en abanico.
# Entre ataque y ataque se queda flotando, que es cuando se le puede pegar.
# ---------------------------------------------------------------------------
class JefeCorvo(Actor):
    """
    El ritmo de la pelea es: vuela -> avisa -> se lanza en picada -> SE CANSA.

    La fase CANSADO es la importante: se queda abajo, a la altura del jugador,
    mareado y SIN poder lastimarte. Es la ventana para pegarle. Sin ella la
    pelea se sentia imposible, porque volaba tan alto que la bola (que viaja
    recta) casi nunca lo alcanzaba.
    """
    FLOTANDO = 0
    AVISO = 1          # se queda quieto un momento: es el aviso de la picada
    PICADA = 2
    CANSADO = 3        # agotado y a tiro: aqui es donde se le pega
    REGRESO = 4

    def __init__(self, x, y, izquierda, derecha, arriba, abajo):
        super().__init__(x, y, 96, 78)
        a = recursos.animaciones()["corvo"]
        # El jefe tambien pelea VOLANDO. Los cuadros de suelo solo se usan
        # al final, cuando cae derrotado.
        self.animaciones = {
            "volar": Animacion(a["volar"], 4),
            "rapido": Animacion(a["volar"], 2),      # picada
            "cansado": Animacion(a["volar"], 11),    # aleteo debil, agotado
            "ataque": Animacion(a["ataque"], 3),
            "derrota": Animacion(a["derrota"], 9, repetir=False),
        }
        self.estado = "volar"
        self.izquierda = izquierda
        self.derecha = derecha
        self.arriba = arriba
        self.abajo = abajo

        self.vida_max = cfg.VIDA_JEFE_CORVO
        self.vida = self.vida_max
        self.titulo = "CORVO, EL GUARDIÁN DEL POZO"
        self.despierto = True
        self.parpadeo = 0

        self.fase = self.FLOTANDO
        self.sin_contacto = False      # True = no lastima al tocarlo
        self.reloj = 90
        self.x = float(x)
        self.y = float(y)
        self.destino = (float(x), float(y))
        self.onda = 0.0
        self.derrotado = False

    # -- dano ------------------------------------------------------------
    def recibir_dano(self, cantidad=1):
        if self.derrotado:
            return False
        self.vida -= cantidad
        self.parpadeo = 10
        if self.vida <= 0:
            self.vida = 0
            self.derrotado = True
            self.vivo = False
            self.poner("derrota", reiniciar=True)
        return self.vivo

    # -- cada cuadro -----------------------------------------------------
    def actualizar(self, nivel, jugador):
        if self.derrotado:
            # derrotado SE CAE al piso y se queda ahi tirado, no flotando
            # donde lo tumbaron
            self.vy = min(self.vy + cfg.GRAVEDAD, cfg.CAIDA_MAXIMA)
            nivel.mover(self, 0, self.vy)
            self.x = float(self.rect.centerx)
            self.y = float(self.rect.centery)
            self.animacion.actualizar()
            return None
        if self.parpadeo > 0:
            self.parpadeo -= 1

        self.onda += 0.08
        self.reloj -= 1
        disparo = None

        if self.fase == self.FLOTANDO:
            # se coloca enfrente del jugador, un poco mas arriba
            lado = 1 if jugador.rect.centerx < self.x else -1
            meta_x = jugador.rect.centerx + lado * 250
            meta_y = jugador.rect.centery - cfg.CORVO_ALTURA + 18 * math.sin(self.onda)
            self.x += (meta_x - self.x) * 0.035
            self.y += (meta_y - self.y) * 0.045
            self.poner("volar")
            self.sin_contacto = False
            if self.reloj <= 0:
                if random.random() < 0.6:
                    self.fase = self.AVISO
                    self.reloj = cfg.CORVO_AVISO
                    self.destino = (float(jugador.rect.centerx),
                                    float(jugador.rect.centery - 10))
                else:
                    self.reloj = 110
                    self.poner("ataque", reiniciar=True)
                    disparo = self._plumas(jugador)

        elif self.fase == self.AVISO:
            # se detiene y aletea fuerte: el jugador alcanza a esquivar
            self.poner("ataque")
            if self.reloj <= 0:
                self.fase = self.PICADA
                self.reloj = 50

        elif self.fase == self.PICADA:
            self.poner("rapido")
            meta_x, meta_y = self.destino
            self.x += (meta_x - self.x) * 0.16
            self.y += (meta_y - self.y) * 0.16
            llego = (abs(self.x - meta_x) < 40 and abs(self.y - meta_y) < 40)
            if self.reloj <= 0 or llego:
                self.fase = self.CANSADO
                self.reloj = cfg.CORVO_CANSANCIO
                self.sin_contacto = True
                self.poner("cansado", reiniciar=True)

        elif self.fase == self.CANSADO:
            # AGOTADO: se queda abajo, a la altura del jugador, y no lastima.
            # Esta es la ventana para pegarle.
            meta_y = jugador.rect.centery - 18
            self.y += (meta_y - self.y) * 0.08
            self.x += math.sin(self.onda * 2.2) * 0.9
            self.poner("cansado")
            if self.reloj <= 0:
                self.fase = self.REGRESO
                self.reloj = 45
                self.sin_contacto = False

        elif self.fase == self.REGRESO:
            self.poner("volar")
            meta_y = jugador.rect.centery - cfg.CORVO_ALTURA - 40
            self.y += (meta_y - self.y) * 0.08
            self.x += (self.x - jugador.rect.centerx) * 0.03
            if self.reloj <= 0:
                self.fase = self.FLOTANDO
                self.reloj = random.randint(*cfg.CORVO_DESCANSO)

        self.x = max(self.izquierda, min(self.x, self.derecha))
        self.y = max(self.arriba, min(self.y, self.abajo))
        self.rect.center = (int(self.x), int(self.y))
        self.mirando = 1 if jugador.rect.centerx > self.x else -1
        self.animacion.actualizar()
        return disparo

    def _plumas(self, jugador):
        direccion = 1 if jugador.rect.centerx > self.x else -1
        return BasuraVoladora(self.rect.centerx, self.rect.centery, direccion,
                              imagen="gota", escala=1.0, rapidez=8.5, altura=-2.0)

    def dibujar(self, pantalla, cx, cy=0, alfa=255):
        if self.parpadeo > 0 and self.parpadeo % 4 < 2:
            alfa = 120
        # Aviso de que se va a lanzar: halo ROJO parpadeante.
        if self.fase == self.AVISO and (self.reloj // 4) % 2 == 0:
            self._aura(pantalla, cx, cy, (255, 90, 90, 90), 40)
        # Esta agotado y se le puede pegar: halo AMARILLO fijo.
        elif self.fase == self.CANSADO:
            self._aura(pantalla, cx, cy, (255, 225, 110, 85), 54)
        super().dibujar(pantalla, cx, cy, alfa)


# ---------------------------------------------------------------------------
# BOMBA: el tanque verde con espinas.
#
# Esta quieto en el piso. Si el jugador lo toca, EXPLOTA y le quita un corazon.
# Pero si le disparas desde lejos, tambien explota y ya no te hace nada:
# conviene reventarlos de lejos en vez de esquivarlos.
# ---------------------------------------------------------------------------
class Bomba:
    DURACION = 34          # cuadros que dura la explosion en pantalla

    def __init__(self, x, suelo):
        self.img = recursos.imagen("nivel", "bomba")
        self.rect = self.img.get_rect()
        self.rect.midbottom = (x, suelo)
        self.viva = True            # sigue existiendo (entera o explotando)
        self.entera = True
        self.fuego = 0
        self.onda = random.uniform(0, 6.28)

    @property
    def radio(self):
        return 20 + int(70 * (1 - self.fuego / float(self.DURACION)))

    def explotar(self):
        if self.entera:
            self.entera = False
            self.fuego = self.DURACION
            return True
        return False

    def actualizar(self, _nivel=None):
        self.onda += 0.09
        if not self.entera:
            self.fuego -= 1
            if self.fuego <= 0:
                self.viva = False

    def zona_de_explosion(self):
        """Lo que alcanza la explosion mientras esta encendida."""
        r = self.radio
        return pygame.Rect(self.rect.centerx - r, self.rect.centery - r,
                           r * 2, r * 2)

    def dibujar(self, pantalla, cx, cy=0):
        if self.entera:
            # late despacio para que se note que es peligroso
            salto = int(2 * math.sin(self.onda))
            pantalla.blit(self.img, (self.rect.x - cx, self.rect.y + salto - cy))
            return
        # la explosion: aros de fuego que se abren y se apagan
        fuerza = self.fuego / float(self.DURACION)
        radio = self.radio
        fuego = pygame.Surface((radio * 2, radio * 2), pygame.SRCALPHA)
        for i, color in enumerate(((255, 240, 160), (255, 170, 60), (200, 70, 30))):
            r = int(radio * (1 - i * 0.3))
            s = 0.5 * fuerza
            pygame.draw.circle(
                fuego, (int(color[0] * s), int(color[1] * s), int(color[2] * s), 255),
                (radio, radio), max(1, r))
        pantalla.blit(fuego, (self.rect.centerx - radio - cx,
                              self.rect.centery - radio - cy),
                      special_flags=pygame.BLEND_RGBA_ADD)


# ---------------------------------------------------------------------------
# JEFE FINAL DEL NIVEL 3: el empresario de la H2O Company
#
# Pelea en DOS fases:
#   1. CON MASCARA. Persigue y lanza su portafolio y fajos de billetes.
#   2. Cuando le queda la mitad de la vida, LA MASCARA SE LE CAE y se ve
#      quien es en realidad. A partir de ahi usa los dibujos sin mascara.
#
# La rotura de la mascara no la decide esta clase: solo avisa con
# 'acaba_de_romper' para que el nivel lance el dialogo de la revelacion.
# ---------------------------------------------------------------------------
class JefeEmpresario(Actor):
    def __init__(self, x, y, izquierda, derecha, escala=1.0):
        super().__init__(x, y, int(70 * escala), int(132 * escala))
        self.escala = escala
        self.izquierda = izquierda
        self.derecha = derecha

        self.animaciones = self._cargar("jefe_mascara")
        self.estado = "quieto"
        self.con_mascara = True
        self.acaba_de_romper = False
        self.rompiendo = 0           # cuadros que dura la escena de la mascara

        self.vida_max = cfg.VIDA_JEFE_FINAL
        self.vida = self.vida_max
        self.titulo = "EL EMPRESARIO"
        self.despierto = True
        self.sin_contacto = False
        self.parpadeo = 0
        self.derrotado = False
        self.llorando = False

        self.rapidez = cfg.VELOCIDAD_JEFE_FINAL
        self.dano_contacto = cfg.DANO_JEFE_FINAL
        self.espera_salto = 0
        self.espera_ataque = random.randint(*cfg.ESPERA_ATAQUE_JEFE_FINAL)

    def _cargar(self, paquete):
        a = recursos.animaciones()[paquete]

        def preparar(cuadros):
            if self.escala == 1.0:
                return cuadros
            return [recursos.escalar(c, self.escala) for c in cuadros]

        animaciones = {
            "quieto": Animacion(preparar(a["quieto"]), 9),
            "caminar": Animacion(preparar(a["caminar"]), 6),
            "correr": Animacion(preparar(a["correr"]), 5),
            "atacar": Animacion(preparar(a["atacar"]), 4, repetir=False),
            "golpe": Animacion(preparar(a["golpe"]), 5, repetir=False),
            "derrota": Animacion(preparar(a["derrota"]), 10, repetir=False),
        }
        if "romper" in a:
            animaciones["romper"] = Animacion(preparar(a["romper"]), 7,
                                              repetir=False)
        if "llorar" in a:
            animaciones["llorar"] = Animacion(preparar(a["llorar"]), 8)
        return animaciones

    # -- dano ------------------------------------------------------------
    def recibir_dano(self, cantidad=1):
        if self.derrotado or self.rompiendo > 0:
            return True
        self.vida -= cantidad
        self.parpadeo = 10

        # a la mitad de la vida se le cae la mascara
        if self.con_mascara and self.vida <= self.vida_max // 2:
            self.con_mascara = False
            self.rompiendo = 60
            self.acaba_de_romper = True
            self.sin_contacto = True
            self.poner("romper", reiniciar=True)
            self.titulo = "EL EMPRESARIO"
            return True

        if self.vida <= 0:
            self.vida = 0
            self.derrotado = True
            self.vivo = False
            self.sin_contacto = True
            self.poner("derrota", reiniciar=True)
        return self.vivo

    def cambiar_a_sin_mascara(self):
        """
        Se llama cuando termina la escena de la mascara rota.

        En la segunda mitad pelea MAS fuerte: ya no finge, y sabe que su
        propio hijo esta enfrente.
        """
        self.animaciones = self._cargar("jefe_sin_mascara")
        self.estado = "quieto"
        self.sin_contacto = False
        self.titulo = "TU PADRE"
        self.rapidez = cfg.VELOCIDAD_JEFE_FINAL * 1.2

    def llorar(self):
        """Al final, derrotado, se queda llorando."""
        self.llorando = True
        if "llorar" in self.animaciones:
            self.poner("llorar", reiniciar=True)

    # -- cada cuadro -----------------------------------------------------
    def actualizar(self, nivel, jugador):
        if self.parpadeo > 0:
            self.parpadeo -= 1

        if self.rompiendo > 0:
            self.rompiendo -= 1
            self.vx = 0.0
            self.vy = min(self.vy + cfg.GRAVEDAD, cfg.CAIDA_MAXIMA)
            nivel.mover(self, 0, self.vy)
            self.animacion.actualizar()
            if self.rompiendo == 0:
                self.cambiar_a_sin_mascara()
            return None

        if self.derrotado or self.llorando:
            self.vx = 0.0
            self.vy = min(self.vy + cfg.GRAVEDAD, cfg.CAIDA_MAXIMA)
            nivel.mover(self, 0, self.vy)
            self.animacion.actualizar()
            return None

        disparo = None
        objetivo = jugador.rect.centerx
        if abs(objetivo - self.rect.centerx) > 110:
            self.mirando = 1 if objetivo > self.rect.centerx else -1
            self.vx = self.rapidez * self.mirando
            self.poner("correr")
        else:
            self.vx = 0.0
            if self.estado != "atacar" or self.animaciones["atacar"].termino:
                self.poner("quieto")

        # brinca si el jugador se le sube a una plataforma o se le acaba el piso
        if self.espera_salto > 0:
            self.espera_salto -= 1
        if self.en_suelo and self.espera_salto == 0:
            mas_arriba = jugador.rect.bottom < self.rect.bottom - 70
            adelante = self.rect.centerx + self.mirando * 95
            sin_piso = not nivel.hay_piso_en(adelante, self.rect.bottom)
            if mas_arriba or sin_piso:
                self.vy = -cfg.FUERZA_SALTO_JEFE
                self.en_suelo = False
                self.espera_salto = 26

        self.espera_ataque -= 1
        if self.espera_ataque <= 0:
            self.espera_ataque = random.randint(*cfg.ESPERA_ATAQUE_JEFE_FINAL)
            self.poner("atacar", reiniciar=True)
            # lanza garrafones de su propia marca: el agua convertida en
            # mercancia, usada como arma
            disparo = BasuraVoladora(self.rect.centerx, self.rect.centery - 16,
                                     self.mirando, imagen="garrafon_h2o_chico",
                                     escala=0.85, rapidez=8.0, altura=-4.0,
                                     carpeta="nivel3")

        self.vy = min(self.vy + cfg.GRAVEDAD, cfg.CAIDA_MAXIMA)
        nivel.mover(self, self.vx, self.vy)
        self.rect.left = max(self.rect.left, self.izquierda)
        self.rect.right = min(self.rect.right, self.derecha)
        self.animacion.actualizar()
        return disparo

    def dibujar(self, pantalla, cx, cy=0, alfa=255):
        if self.parpadeo > 0 and self.parpadeo % 4 < 2:
            alfa = 120
        if self.rompiendo > 0:
            self._aura(pantalla, cx, cy, (255, 240, 180, 70), 50)
        super().dibujar(pantalla, cx, cy, alfa)


# ---------------------------------------------------------------------------
# PELIGRO: puas, techos de puas y demas cosas fijas que lastiman.
#
# No son solo adornos con caja de dano: se pueden ROMPER a disparos, y al
# romperse sueltan agua. Asi el jugador tiene dos salidas ante cualquier
# peligro: esquivarlo, o gastar unos tiros y de paso llevarse las gotas.
# ---------------------------------------------------------------------------
class Peligro:
    ROTURA = 26            # cuadros que dura la nubecita al romperse

    def __init__(self, caja, img, x, y, vida=None, gotas=None):
        self.caja = caja
        self.img = img
        self.x = x
        self.y = y
        self.vida = cfg.VIDA_PELIGRO if vida is None else vida
        self.gotas = cfg.GOTAS_POR_PELIGRO if gotas is None else gotas
        self.entero = True
        self.parpadeo = 0
        self.rompiendo = 0

    @property
    def visible(self):
        return self.entero or self.rompiendo > 0

    @property
    def caja_disparo(self):
        """
        Zona para que le peguen las bolas. Es MAS GRANDE que la caja de dano
        a proposito: la bola viaja a la altura del pecho y las puas estan
        pegadas al piso, asi que con la caja justa le pasaban por encima y
        era imposible romperlas.
        """
        ancho, alto = self.img.get_size()
        return pygame.Rect(self.x, self.y - 70, ancho, alto + 140)

    def recibir_dano(self, cantidad=1):
        """Devuelve True si con este golpe se rompio."""
        if not self.entero:
            return False
        self.vida -= cantidad
        self.parpadeo = 8
        if self.vida <= 0:
            self.entero = False
            self.rompiendo = self.ROTURA
            return True
        return False

    def actualizar(self):
        if self.parpadeo > 0:
            self.parpadeo -= 1
        if self.rompiendo > 0:
            self.rompiendo -= 1

    def dibujar(self, pantalla, cx, cy=0):
        if self.entero:
            img = self.img
            if self.parpadeo > 0 and self.parpadeo % 4 < 2:
                img = img.copy()
                img.fill((255, 255, 255, 0), special_flags=pygame.BLEND_RGBA_ADD)
            pantalla.blit(img, (self.x - cx, self.y - cy))
            return
        if self.rompiendo <= 0:
            return
        # al romperse: una nubecita de polvo que se abre y se apaga
        fuerza = self.rompiendo / float(self.ROTURA)
        radio = int(self.caja.width * 0.5 * (1.6 - fuerza))
        if radio < 2:
            return
        polvo = pygame.Surface((radio * 2, radio * 2), pygame.SRCALPHA)
        for i in range(4):
            s = 0.09 * fuerza
            pygame.draw.circle(polvo, (int(220 * s), int(230 * s), int(255 * s), 255),
                               (radio, radio), max(1, int(radio * (1 - i * 0.22))))
        pantalla.blit(polvo, (self.caja.centerx - radio - cx,
                              self.caja.centery - radio - cy),
                      special_flags=pygame.BLEND_RGBA_ADD)
