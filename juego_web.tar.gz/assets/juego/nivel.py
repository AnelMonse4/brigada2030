# -*- coding: utf-8 -*-
"""
MOTOR DE NIVELES

Aqui vive todo lo que los tres niveles hacen IGUAL:
  * chocar con el piso y las plataformas
  * mover la camara
  * recibir dano por puas, agua y enemigos
  * recolectar gotas
  * los cuadros de dialogo
  * el HUD (corazones y contador de gotas)

Cada nivel (nivel1.py, nivel2.py) solo describe SU mapa y SUS reglas propias.
Asi, si arreglamos algo aqui, se arregla en los tres niveles a la vez.
"""
import math
import random

import pygame

from . import ajustes as cfg
from . import recursos
from .entidades import Jugador, Corvo, Gota


# ---------------------------------------------------------------------------
# Cuadro de dialogo
# ---------------------------------------------------------------------------
class Dialogo:
    """
    Cuadro de texto de abajo. Se avanza con ESPACIO o ENTER.

    Cada linea es (quien, nombre, frase). Si 'quien' es "heroe", se usa el
    protagonista que haya elegido el jugador (Aqua o Yani).
    """

    def __init__(self, lineas, personaje="aqua"):
        self.personaje = personaje
        self.lineas = list(lineas)
        self.indice = 0
        self.letras = 0
        self.activo = bool(self.lineas)

    def avanzar(self):
        if not self.activo:
            return
        frase = self.lineas[self.indice][2]
        if self.letras < len(frase):
            self.letras = len(frase)          # primero completa el texto
        elif self.indice < len(self.lineas) - 1:
            self.indice += 1
            self.letras = 0
        else:
            self.activo = False

    def actualizar(self):
        if not self.activo:
            return
        if self.letras < len(self.lineas[self.indice][2]):
            self.letras += 1

    def dibujar(self, pantalla):
        if not self.activo:
            return
        quien, nombre, frase = self.lineas[self.indice]
        if quien == "heroe":
            quien = self.personaje
            nombre = recursos.PROTAGONISTAS[self.personaje]["nombre"]

        caja = pygame.Rect(90, cfg.ALTO - 190, cfg.ANCHO - 180, 150)
        fondo = pygame.Surface(caja.size, pygame.SRCALPHA)
        fondo.fill((*cfg.PANEL, 235))
        pantalla.blit(fondo, caja.topleft)
        pygame.draw.rect(pantalla, cfg.BORDE, caja, 3)

        retrato = recursos.escalar(recursos.imagen("nivel", "retrato_" + quien), 0.52)
        pantalla.blit(retrato, (caja.x + 14, caja.bottom - retrato.get_height() - 8))

        recursos.texto(pantalla, nombre, caja.x + 165, caja.y + 18,
                       tamano=22, color=cfg.AGUA, negrita=True)
        recursos.texto(pantalla, frase[:self.letras], caja.x + 165, caja.y + 58,
                       tamano=24)
        recursos.texto(pantalla, "[TOCA] continuar", caja.right - 240,
                       caja.bottom - 32, tamano=16, color=cfg.GRIS)


# ---------------------------------------------------------------------------
# Base de todos los niveles
# ---------------------------------------------------------------------------
class NivelBase:
    # --- cosas que cada nivel cambia ---
    MUSICA = "2_desarrollo"
    ROTULO = ""
    LARGO = 8000
    SUELO_Y = cfg.SUELO_Y
    COLOR_CIELO = (40, 40, 60)
    INICIO_X = 160
    SIGUIENTE = None              # a que pantalla se va al ganar
    CAMARA_ALTA = 0               # cuanto puede subir la camara (0 = fija)
    CORVO_ACOMPANA = True         # False = Corvo no se ve hasta el final

    def __init__(self, personaje="aqua"):
        self.personaje = personaje
        self.camara_x = 0.0
        self.camara_y = 0.0
        self.terminado = False
        self.resultado = None          # "ganado" o "perdido"
        self.fundido = 0
        self.temblor = 0
        self.aviso = None              # [texto, cuadros que le quedan]
        self.cinematica = None         # nombre de la escena final en curso
        # a donde camina el protagonista en la escena final. Si se cae, se
        # le repone HACIA ALLA y no de regreso.
        self.destino_cinematica = None
        # Cuanto se sube la camara durante las escenas finales.
        # El cuadro de dialogo tapa la parte de abajo de la pantalla, que es
        # justo donde esta el piso. Sin esto, lo que pasa en el suelo durante
        # una conversacion (Corvo tirado, por ejemplo) no se ve.
        self.alzar = 0.0

        # --- escenario (lo llena construir()) ---
        self.solidos = []              # rects con los que se choca por todos lados
        self.plataformas = []          # (rect, imagen, y)  se pisan desde arriba
        self.peligros = []             # (rect, imagen, x, y) puas: quitan vida
        self.agua = []                 # (rect, imagen) rio: quita vida y te regresa
        self.bombas = []               # tanques verdes que explotan al tocarlos
        self.adornos_atras = []        # (x, y, imagen)
        self.adornos_frente = []       # (x, y, imagen)
        self.puntos_seguros = [self.INICIO_X]

        self.construir()

        # --- personajes y objetos ---
        self.jugador = Jugador(self.INICIO_X, self.SUELO_Y, personaje)
        self.corvo = Corvo(self.INICIO_X - 100, self.SUELO_Y - 220)
        self.corvo.escondido = not self.CORVO_ACOMPANA
        self.bolas = []
        self.proyectiles = []          # lo que lanzan los enemigos
        self.enemigos = self.crear_enemigos()
        self.jefe = None
        self.gotas = [Gota(x, y) for x, y in self.lista_gotas()]
        self.total_gotas = len(self.gotas)

        self.dialogo = Dialogo(self.DIALOGO_INICIO, personaje) if self.DIALOGO_INICIO else None
        self.dialogo_final = None
        self.ultimo_seguro = self.puntos_seguros[0]

        recursos.musica(self.MUSICA, 0.45)

    # -- lo que cada nivel debe definir ---------------------------------
    DIALOGO_INICIO = ()

    def construir(self):
        raise NotImplementedError

    def crear_enemigos(self):
        return []

    def lista_gotas(self):
        return []

    def dibujar_fondo(self, pantalla, cx, cy):
        pantalla.fill(self.COLOR_CIELO)

    # ganchos opcionales
    def actualizar_extra(self):
        pass

    def dibujar_extra(self, pantalla, cx, cy):
        pass

    def dibujar_hud_extra(self, pantalla):
        pass

    def revisar_jefe(self):
        pass

    def actualizar_cinematica(self):
        pass

    # ===================================================================
    # COLISIONES
    # ===================================================================
    def choca_con_solido(self, rect):
        return rect.collidelist(self.solidos) != -1

    def hay_piso_en(self, x, y_pies, profundidad=160):
        """True si hay suelo pisable justo debajo de ese punto."""
        sonda = pygame.Rect(x - 6, y_pies - 8, 12, profundidad)
        if sonda.collidelist(self.solidos) != -1:
            return True
        return any(sonda.colliderect(caja) for caja, _img, _y in self.plataformas)

    def hay_techo(self, rect):
        """True si al pararse el personaje se pegaria con algo arriba."""
        prueba = pygame.Rect(rect.x, rect.bottom - cfg.ALTO_JUGADOR,
                             rect.width, cfg.ALTO_JUGADOR)
        return prueba.collidelist(self.solidos) != -1

    def mover(self, actor, vx, vy):
        """Mueve al actor resolviendo choques: primero en X y luego en Y."""
        actor.rect.x += int(round(vx))
        for solido in self.solidos:
            if actor.rect.colliderect(solido):
                if vx > 0:
                    actor.rect.right = solido.left
                elif vx < 0:
                    actor.rect.left = solido.right

        actor.rect.x = max(0, min(actor.rect.x, self.LARGO - actor.rect.width))

        abajo_antes = actor.rect.bottom
        actor.rect.y += int(round(vy))
        actor.en_suelo = False

        for solido in self.solidos:
            if actor.rect.colliderect(solido):
                if vy > 0:
                    actor.rect.bottom = solido.top
                    actor.en_suelo = True
                    actor.vy = 0.0
                elif vy < 0:
                    actor.rect.top = solido.bottom
                    actor.vy = 0.0

        # las plataformas solo frenan si vienes CAYENDO desde arriba
        if vy > 0:
            for caja, _img, _y in self.plataformas:
                if actor.rect.colliderect(caja) and abajo_antes <= caja.top + 8:
                    actor.rect.bottom = caja.top
                    actor.en_suelo = True
                    actor.vy = 0.0

    # ===================================================================
    # EVENTOS
    # ===================================================================
    def tecla(self, tecla):
        charla = self.dialogo_final or self.dialogo
        if charla and charla.activo:
            if tecla in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER):
                charla.avanzar()
            return
        if self.terminado or self.cinematica:
            return
        if tecla in (pygame.K_UP, pygame.K_w, pygame.K_SPACE):
            self.jugador.saltar()
        elif tecla in (pygame.K_x, pygame.K_z, pygame.K_j):
            bola = self.jugador.disparar()
            if bola:
                self.bolas.append(bola)

    # ===================================================================
    # CADA CUADRO
    # ===================================================================
    def actualizar(self, teclas):
        # 1) dialogo de apertura: el juego espera
        if self.dialogo and self.dialogo.activo:
            self.dialogo.actualizar()
            self.corvo.actualizar(self.jugador)
            self.mover_camara()
            return

        # 2) escena final (Corvo rescatando, teletransporte...)
        if self.cinematica:
            self.actualizar_alzado()
            self.actualizar_cinematica()
            # red de seguridad: durante las escenas finales no hay revision de
            # peligros, asi que si el protagonista venia cayendo cuando murio
            # el jefe, se caeria para siempre fuera del mundo.
            if self.jugador.rect.top > cfg.ALTO + 200:
                self.plantar_en_suelo(self.jugador, self.destino_cinematica)
            return

        if self.terminado:
            return

        if self.temblor > 0:
            self.temblor -= 1
        if self.aviso:
            self.aviso[1] -= 1
            if self.aviso[1] <= 0:
                self.aviso = None

        self.jugador.controlar(teclas, self)
        self.jugador.actualizar(self)
        self.corvo.actualizar(self.jugador)

        self.revisar_jefe()
        self._actualizar_enemigos()
        self._actualizar_disparos()
        self._actualizar_gotas()
        self._actualizar_bombas()
        self._revisar_escenario()
        self.actualizar_extra()
        self.mover_camara()

        if self.jugador.derrotado and self.jugador.animaciones["caido"].termino:
            self.fundido += 4
            if self.fundido >= 255:
                self.terminado = True
                self.resultado = "perdido"

    def _actualizar_enemigos(self):
        for enemigo in self.enemigos:
            if not enemigo.vivo:
                continue
            # solo se mueven los que estan cerca de la pantalla
            if abs(enemigo.rect.centerx - self.jugador.rect.centerx) > 1400:
                continue
            disparo = enemigo.actualizar(self, self.jugador)
            if disparo:
                self.proyectiles.append(disparo)
            # un enemigo que va huyendo ya no lastima al tocarlo
            if (not getattr(enemigo, "sin_contacto", False)
                    and enemigo.rect.colliderect(self.jugador.rect)):
                empuje = 7 if self.jugador.rect.centerx > enemigo.rect.centerx else -7
                self.jugador.recibir_dano(cfg.DANO_ENEMIGO, empuje)

        if self.jefe and self.jefe.vivo:
            disparo = self.jefe.actualizar(self, self.jugador)
            if disparo:
                self.proyectiles.append(disparo)
            # un jefe agotado (Corvo despues de su picada) no lastima al
            # tocarlo: esa es justo la ventana para acercarse y pegarle
            if (not getattr(self.jefe, "sin_contacto", False)
                    and self.jefe.rect.colliderect(self.jugador.rect)):
                empuje = 11 if self.jugador.rect.centerx > self.jefe.rect.centerx else -11
                dano = getattr(self.jefe, "dano_contacto", cfg.DANO_ENEMIGO)
                self.jugador.recibir_dano(dano, empuje)

    def _actualizar_disparos(self):
        for bola in self.bolas:
            bola.actualizar(self)
            if not bola.viva:
                continue
            for enemigo in self.enemigos:
                if enemigo.vivo and bola.rect.colliderect(enemigo.rect):
                    seguia_vivo = enemigo.vivo and not enemigo.huyendo
                    enemigo.recibir_dano(cfg.DANO_BOLA)
                    bola.viva = False
                    # al caer (o al salir huyendo) suelta gotas de agua
                    if seguia_vivo and (not enemigo.vivo or enemigo.huyendo):
                        self.soltar_gotas(enemigo)
                    break
            # las puas y demas peligros fijos tambien se rompen a disparos,
            # y al romperse sueltan agua
            if bola.viva:
                for peligro in self.peligros:
                    if peligro.entero and bola.rect.colliderect(peligro.caja_disparo):
                        bola.viva = False
                        if peligro.recibir_dano(cfg.DANO_BOLA):
                            self.soltar_gotas(peligro, peligro.gotas)
                        break

            if (bola.viva and self.jefe and self.jefe.vivo
                    and bola.rect.colliderect(self.jefe.rect)):
                self.jefe.recibir_dano(cfg.DANO_BOLA)
                bola.viva = False
                self.temblor = 8
                if not self.jefe.vivo:
                    self.al_vencer_jefe()
        self.bolas = [b for b in self.bolas if b.viva]

        for proyectil in self.proyectiles:
            proyectil.actualizar(self)
            if proyectil.viva and proyectil.rect.colliderect(self.jugador.rect):
                empuje = 8 if getattr(proyectil, "vx", 0) > 0 else -8
                self.jugador.recibir_dano(1, empuje)
                proyectil.viva = False
        self.proyectiles = [p for p in self.proyectiles if p.viva]

    def soltar_gotas(self, enemigo, cuantas=None):
        """
        Deja unas gotas donde cayo el enemigo.

        Es el premio por pelear: si no, conviene mas esquivarlos a todos y
        los enemigos se vuelven un estorbo en vez de una oportunidad.
        """
        if cuantas is None:
            cuantas = getattr(enemigo, "suelta_gotas", cfg.GOTAS_POR_ENEMIGO)
        caja = getattr(enemigo, "rect", None) or enemigo.caja
        centro = caja.centerx
        arriba = caja.top + 10
        for i in range(cuantas):
            separacion = (i - (cuantas - 1) / 2.0) * 46
            gota = Gota(int(centro + separacion), arriba)
            self.gotas.append(gota)
            self.total_gotas += 1

    def _actualizar_gotas(self):
        for peligro in self.peligros:
            peligro.actualizar()

        for gota in self.gotas:
            if not gota.viva:
                continue
            gota.actualizar()
            if gota.rect.colliderect(self.jugador.rect):
                gota.viva = False
                self.jugador.gotas += 1
                # el agua devuelve vida: cada 10 gotas, un corazon de vuelta
                if self.jugador.gotas % 10 == 0 and self.jugador.vidas < cfg.VIDAS:
                    self.jugador.vidas += 1
                    self.aviso = ["+1 CORAZÓN", 110]

    def _actualizar_bombas(self):
        """
        Los tanques verdes explotan al tocarlos (y te quitan un corazon) o al
        recibir un disparo (y entonces ya no te hacen nada).
        """
        for bomba in self.bombas:
            if not bomba.viva:
                continue
            bomba.actualizar(self)

            if bomba.entera:
                for bola in self.bolas:
                    if bola.viva and bola.rect.colliderect(bomba.rect):
                        bomba.explotar()
                        bola.viva = False
                        self.temblor = max(self.temblor, 10)
                        # premio por reventarla de lejos en vez de rodearla
                        self.soltar_gotas(bomba, cfg.GOTAS_POR_PELIGRO)
                        break

            if bomba.entera and bomba.rect.colliderect(self.jugador.rect):
                bomba.explotar()
                self.temblor = max(self.temblor, 16)
                empuje = 9 if self.jugador.rect.centerx > bomba.rect.centerx else -9
                self.jugador.recibir_dano(cfg.DANO_BOMBA, empuje)
            elif not bomba.entera and bomba.fuego > bomba.DURACION - 8:
                # los primeros cuadros de la llamarada tambien alcanzan
                if bomba.zona_de_explosion().colliderect(self.jugador.rect):
                    empuje = 9 if self.jugador.rect.centerx > bomba.rect.centerx else -9
                    self.jugador.recibir_dano(cfg.DANO_BOMBA, empuje)

            for enemigo in self.enemigos:
                if (enemigo.vivo and not bomba.entera
                        and bomba.fuego > bomba.DURACION - 8
                        and bomba.zona_de_explosion().colliderect(enemigo.rect)):
                    enemigo.recibir_dano(2)

        self.bombas = [b for b in self.bombas if b.viva]

    def _revisar_escenario(self):
        jugador = self.jugador
        if jugador.derrotado:
            return

        for peligro in self.peligros:
            if peligro.entero and jugador.rect.colliderect(peligro.caja):
                empuje = 8 if jugador.mirando < 0 else -8
                jugador.recibir_dano(cfg.DANO_PUAS, empuje)
                break

        for caja, _img in self.agua:
            if jugador.rect.colliderect(caja):
                jugador.recibir_dano(cfg.DANO_RIO)
                self.regresar_a_lugar_seguro()
                break

        if jugador.rect.top > cfg.ALTO + self.SUELO_Y:
            jugador.recibir_dano(cfg.DANO_RIO)
            self.regresar_a_lugar_seguro()

        if jugador.en_suelo:
            for punto in self.puntos_seguros:
                if punto <= jugador.rect.centerx:
                    self.ultimo_seguro = punto

    def caminar_hasta(self, destino, rapidez=2.4):
        """
        Lleva al protagonista caminando hasta 'destino' en una escena final.

        Durante las escenas el jugador no controla nada, asi que el juego
        tiene que resolverle el camino: va hacia donde sea (adelante o
        atras), BRINCA los huecos que se le aparecen, y si aun asi se cae,
        se le repone en la plataforma mas cercana HACIA EL DESTINO, nunca de
        regreso. Sin esto se quedaba atorado o se caia al agua y la escena
        final nunca terminaba.

        Devuelve True cuando ya llego.
        """
        self.destino_cinematica = destino
        jugador = self.jugador
        distancia = destino - jugador.rect.centerx

        if abs(distancia) > 10:
            jugador.mirando = 1 if distancia > 0 else -1
            jugador.vx = rapidez * jugador.mirando
            jugador.poner("caminar")
            adelante = jugador.rect.centerx + jugador.mirando * 58
            if (jugador.en_suelo
                    and not self.hay_piso_en(adelante, jugador.rect.bottom)):
                jugador.saltar()
        else:
            jugador.vx = 0.0
            jugador.poner("quieto")

        self.mover(jugador, jugador.vx, jugador.vy)

        # red de seguridad: si se paso de largo hacia abajo, lo reponemos
        if jugador.rect.top > self.SUELO_Y + 140:
            self.plantar_en_suelo(jugador, destino)

        return abs(destino - jugador.rect.centerx) <= 10

    def plantar_en_suelo(self, actor, hacia=None):
        """
        Deja al actor parado sobre suelo firme.

        Normalmente escoge el punto seguro mas cercano HACIA ATRAS. Pero si
        se indica 'hacia' (a donde va caminando en una escena final), escoge
        el que este de ese lado: asi nunca lo manda de regreso a media
        caminata, que es lo que hacia que se quedara dando vueltas.
        """
        if hacia is not None:
            adelante = [p for p in self.puntos_seguros
                        if (p >= actor.rect.centerx) == (hacia >= actor.rect.centerx)]
            candidatos = adelante or self.puntos_seguros
            destino = min(candidatos, key=lambda p: abs(p - actor.rect.centerx))
        else:
            destino = self.puntos_seguros[0]
            for punto in self.puntos_seguros:
                if punto <= actor.rect.centerx:
                    destino = punto
        suelo = self.SUELO_Y
        sonda = pygame.Rect(destino - 8, 0, 16, 4000)
        for solido in self.solidos:
            if sonda.colliderect(solido):
                suelo = min(suelo, solido.top) if suelo else solido.top
                suelo = solido.top
                break
        actor.rect.midbottom = (destino, suelo)
        actor.vx = 0.0
        actor.vy = 0.0
        actor.en_suelo = True

    def regresar_a_lugar_seguro(self):
        self.jugador.rect.midbottom = (self.ultimo_seguro, self.SUELO_Y - 10)
        self.jugador.vy = 0.0
        self.jugador.vx = 0.0

    def al_vencer_jefe(self):
        pass

    def cerrar_dialogos(self):
        """
        Descarta cualquier dialogo que siguiera abierto. Si no se hace, un
        dialogo a medias congela el juego: actualizar() se corta en el,
        y la escena final nunca llega a correr.
        """
        self.dialogo = None

    def actualizar_alzado(self):
        """Sube la camara mientras hay dialogo en una escena final."""
        charla = self.dialogo_final or self.dialogo
        hablando = bool(charla and charla.activo)
        objetivo = cfg.ALZADO_EN_DIALOGO if hablando else 0.0
        self.alzar += (objetivo - self.alzar) * 0.08

    def mover_camara(self):
        objetivo_x = self.jugador.rect.centerx - cfg.ANCHO // 2
        objetivo_x = max(0, min(objetivo_x, self.LARGO - cfg.ANCHO))
        self.camara_x += (objetivo_x - self.camara_x) * 0.12

        if self.CAMARA_ALTA:
            # la camara sube si el jugador trepa, pero nunca baja del suelo
            objetivo_y = min(0, max(-self.CAMARA_ALTA,
                                    self.jugador.rect.centery - cfg.ALTO // 2 - 40))
            self.camara_y += (objetivo_y - self.camara_y) * 0.09
        else:
            self.camara_y = 0.0

    # ===================================================================
    # DIBUJO
    # ===================================================================
    def dibujar(self, pantalla):
        cx = int(self.camara_x)
        cy = int(self.camara_y + self.alzar)
        if self.temblor > 0:
            cx += random.randint(-5, 5)
            cy += random.randint(-3, 3)

        self.dibujar_fondo(pantalla, cx, cy)
        self._dibujar_escenario(pantalla, cx, cy)

        for gota in self.gotas:
            if gota.viva and -60 < gota.rect.x - cx < cfg.ANCHO + 60:
                gota.dibujar(pantalla, cx, cy)

        if not self.corvo.escondido:
            self.corvo.dibujar(pantalla, cx, cy)

        for enemigo in self.enemigos:
            if enemigo.vivo and -250 < enemigo.rect.x - cx < cfg.ANCHO + 250:
                enemigo.dibujar(pantalla, cx, cy)
        # se dibuja aunque ya este derrotado: su animacion de caida y su
        # cuerpo tirado en el piso son parte de la escena final
        if self.jefe is not None:
            self.jefe.dibujar(pantalla, cx, cy)

        for bomba in self.bombas:
            if not (-200 < bomba.rect.x - cx < cfg.ANCHO + 200):
                continue
            if bomba.entera:
                self._marca_de_peligro(pantalla, bomba.rect.x, bomba.rect.y,
                                       bomba.img, cx, cy)
            bomba.dibujar(pantalla, cx, cy)

        for bola in self.bolas:
            bola.dibujar(pantalla, cx, cy)
        for proyectil in self.proyectiles:
            proyectil.dibujar(pantalla, cx, cy)

        self.jugador.dibujar(pantalla, cx, cy)

        for x, y, img in self.adornos_frente:
            if -400 < x - cx < cfg.ANCHO + 400:
                pantalla.blit(img, (x - cx, y - cy))

        self.dibujar_extra(pantalla, cx, cy)
        self._dibujar_hud(pantalla)

        charla = self.dialogo_final or self.dialogo
        if charla and charla.activo:
            charla.dibujar(pantalla)

        if self.fundido > 0:
            velo = pygame.Surface((cfg.ANCHO, cfg.ALTO))
            velo.fill(cfg.NEGRO)
            velo.set_alpha(min(255, self.fundido))
            pantalla.blit(velo, (0, 0))

    def _dibujar_escenario(self, pantalla, cx, cy):
        for x, y, img in self.adornos_atras:
            if -400 < x - cx < cfg.ANCHO + 400:
                pantalla.blit(img, (x - cx, y - cy))

        for caja, img in self.agua:
            if caja.right - cx < -200 or caja.left - cx > cfg.ANCHO + 200:
                continue
            if img is None:
                continue
            ancho = img.get_width()
            x = caja.left
            while x < caja.right:
                pantalla.blit(img, (x - cx, caja.top - cy))
                x += ancho

        self.dibujar_terreno(pantalla, cx, cy)

        for caja, img, y in self.plataformas:
            if -500 < caja.x - cx < cfg.ANCHO + 500:
                pantalla.blit(img, (caja.x - cx, y - cy))

        for peligro in self.peligros:
            if not peligro.visible or not (-400 < peligro.x - cx < cfg.ANCHO + 400):
                continue
            if peligro.entero:
                self._marca_de_peligro(pantalla, peligro.x, peligro.y,
                                       peligro.img, cx, cy)
            peligro.dibujar(pantalla, cx, cy)

    @staticmethod
    def _marca_de_peligro(pantalla, x, y, img, cx, cy):
        """
        Franja de advertencia y resplandor rojo debajo de todo lo que lastima.

        Sin esto el jugador no distingue que es utileria y que hay que
        esquivar: los botes, las cajas y las puas se ven igual de "cosas
        tiradas en el piso". Con la marca, el peligro se lee de lejos.

        Se dibuja sobre el ANCHO DEL DIBUJO (no sobre la caja de dano, que es
        mas angosta) para que la franja cubra justo lo que se ve.
        """
        ancho, alto = img.get_size()
        izq = x - cx
        base = y + alto - cy
        if izq + ancho < 0 or izq > cfg.ANCHO:
            return

        latido = 0.5 + 0.5 * math.sin(pygame.time.get_ticks() * 0.006)

        # resplandor rojo detras del objeto
        halo = pygame.Surface((ancho + 46, alto + 34), pygame.SRCALPHA)
        for i in range(6):
            s = 0.1 + 0.07 * latido
            pygame.draw.ellipse(halo, (int(235 * s), int(46 * s), int(40 * s), 255),
                                halo.get_rect().inflate(-i * 9, -i * 6))
        pantalla.blit(halo, (izq - 23, y - 17 - cy),
                      special_flags=pygame.BLEND_RGBA_ADD)

        # franja de obra amarilla y negra, pegada al piso
        franja = pygame.Rect(izq - 6, base - 4, ancho + 12, 9)
        pygame.draw.rect(pantalla, (26, 22, 18), franja)
        recorte = pantalla.get_clip()
        pantalla.set_clip(franja)
        for rayita in range(franja.left - 12, franja.right + 12, 12):
            pygame.draw.line(pantalla, (248, 198, 40),
                             (rayita, franja.bottom), (rayita + 9, franja.top), 5)
        pantalla.set_clip(recorte)
        pygame.draw.rect(pantalla, (248, 198, 40), franja, 1)

    def dibujar_terreno(self, pantalla, cx, cy):
        """Por defecto pinta los solidos como tierra. Nivel 1 lo reemplaza."""
        for solido in self.solidos:
            rect = pygame.Rect(solido.left - cx, solido.top - cy, solido.width, 200)
            if rect.right < -50 or rect.left > cfg.ANCHO + 50:
                continue
            pygame.draw.rect(pantalla, (52, 38, 30), rect)
            pygame.draw.rect(pantalla, (86, 64, 44), (rect.x, rect.y, rect.width, 12))
            pygame.draw.rect(pantalla, (118, 180, 70), (rect.x, rect.y, rect.width, 5))

    def _dibujar_hud(self, pantalla):
        lleno = recursos.imagen("hud", "corazon_lleno")
        vacio = recursos.imagen("hud", "corazon_vacio")
        for i in range(cfg.VIDAS):
            img = lleno if i < self.jugador.vidas else vacio
            pantalla.blit(img, (24 + i * (img.get_width() + 6), 22))

        gota = recursos.imagen("nivel", "gota_hud")
        pantalla.blit(gota, (26, 86))
        recursos.texto(pantalla, "%d / %d" % (self.jugador.gotas, self.total_gotas),
                       26 + gota.get_width() + 10, 88, tamano=24,
                       color=cfg.AGUA, negrita=True)

        if self.aviso:
            recursos.texto(pantalla, self.aviso[0], cfg.ANCHO // 2, 150,
                           tamano=34, color=cfg.ROJO, centrado=True, negrita=True)

        recursos.texto(pantalla, self.ROTULO, cfg.ANCHO // 2, 24, tamano=20,
                       color=cfg.VERDE_TOXICO, centrado=True, negrita=True)

        if self.jefe and self.jefe.vivo and getattr(self.jefe, "despierto", True):
            self._barra_de_jefe(pantalla)

        self.dibujar_hud_extra(pantalla)

    def _barra_de_jefe(self, pantalla):
        ancho = 520
        x = (cfg.ANCHO - ancho) // 2
        y = cfg.ALTO - 60
        pygame.draw.rect(pantalla, (20, 16, 22), (x - 4, y - 4, ancho + 8, 32))
        pygame.draw.rect(pantalla, (70, 20, 20), (x, y, ancho, 24))
        porcion = int(ancho * self.jefe.vida / self.jefe.vida_max)
        pygame.draw.rect(pantalla, cfg.ROJO, (x, y, porcion, 24))
        pygame.draw.rect(pantalla, cfg.BORDE, (x - 4, y - 4, ancho + 8, 32), 2)
        recursos.texto(pantalla, self.jefe.titulo, cfg.ANCHO // 2, y - 32,
                       tamano=18, color=cfg.BLANCO, centrado=True, negrita=True)


# ---------------------------------------------------------------------------
# Utilidad: tapizar una imagen a lo ancho, espejeando una si y una no
# para que no se note la union.
# ---------------------------------------------------------------------------
_espejos = {}


def tapizar_espejo(pantalla, img, desplazamiento, y):
    ancho = img.get_width()
    if ancho <= 0:
        return
    primera = int(desplazamiento) // ancho
    offset = int(desplazamiento) % ancho
    x = -offset
    i = 0
    # el espejo se calcula una sola vez por imagen (voltear cuesta mucho)
    espejo = _espejos.get(id(img))
    if espejo is None or espejo[0] is not img:
        espejo = (img, pygame.transform.flip(img, True, False))
        _espejos[id(img)] = espejo
    espejo = espejo[1]
    while x < cfg.ANCHO:
        pieza = espejo if (primera + i) % 2 else img
        pantalla.blit(pieza, (x, y))
        x += ancho
        i += 1
