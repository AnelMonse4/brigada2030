# -*- coding: utf-8 -*-
"""
NIVEL 3 - LA PLANTA DE LA H2O COMPANY

El ultimo nivel. El protagonista y Corvo entran juntos a la planta que
embotella y contamina el agua. Cruzan pasarelas de metal sobre charcos
toxicos, esquivando fugas y peleando con los obreros de la planta, hasta
llegar al JEFE FINAL: el empresario enmascarado.

La pelea es tambien una discusion. El empresario tiene argumentos buenos
(empleo, medicinas, progreso) y los dice en serio. El protagonista y Corvo
le responden con el unico argumento que no se puede rebatir: el agua no se
fabrica, y sin ella no hay progreso que valga.

A la MITAD de su vida se le cae la mascara y resulta ser el padre del
protagonista, que se fue de la casa convencido de que servia a un bien mayor.

El mapa lo genera herramientas/rearmar_nivel3.py.
"""
import math
import random

import pygame

from . import ajustes as cfg
from . import recursos
from .nivel import NivelBase, Dialogo
from .entidades import Enemigo, JefeEmpresario, Peligro


LARGO = 8800
PISO_TOXICO = 624         # el charco de la planta: si caes, quema

# ---------------------------------------------------------------------------
# DATOS DEL MAPA (los escribe herramientas/rearmar_nivel3.py)
# ---------------------------------------------------------------------------
# PLATAFORMAS: (x, altura de la superficie, imagen).
# Generado por herramientas/rearmar_nivel3.py.
PLATAFORMAS = [
    (0, 560, "plataforma_rejilla_metal"),
    (527, 530, "pasarela_metal_barandal"),
    (972, 560, "viga_metal_larga_02"),
    (1484, 500, "pasarela_metal_barandal_roto"),
    (2015, 540, "viga_metal_mediana"),
    (2345, 560, "plataforma_rejilla_metal"),
    (2872, 510, "pasarela_metal_barandal"),
    (3317, 560, "viga_metal_larga_02"),
    (3829, 530, "pasarela_metal_barandal_roto"),
    (4360, 560, "viga_metal_mediana"),
    (4690, 500, "plataforma_rejilla_metal"),
    (5217, 540, "pasarela_metal_barandal"),
    (5662, 560, "viga_metal_larga_02"),
    (6174, 520, "pasarela_metal_barandal_roto"),
    (6705, 560, "viga_metal_mediana"),
    (7035, 540, "plataforma_rejilla_metal"),
    (7300, 560, "plataforma_rejilla_metal"),
    (7750, 560, "plataforma_rejilla_metal"),
    (8200, 560, "plataforma_rejilla_metal"),
]

# ALTAS: (x, y, imagen). Pasarelas altas, dos dentro de la arena del jefe.
ALTAS = [
    (366, 380, "viga_metal_mediana"),
    (1850, 350, "viga_metal_mediana"),
    (3153, 360, "viga_metal_mediana"),
    (4525, 350, "viga_metal_mediana"),
    (6016, 370, "viga_metal_mediana"),
    (7680, 410, "viga_metal_mediana"),
    (8280, 410, "viga_metal_mediana"),
]

# PELIGROS: (x, imagen). Fugas, chispas y escombro que hacen dano.
PELIGROS = [
    (1577, "cable_electrico_cortado_chispas"),
    (3024, "barril_oxidado_fuga_acido"),
    (4010, "tubo_codo_goteando_agua_toxica"),
    (5308, "escombro_varillas_puntiagudas"),
    (6359, "barril_verde_derrame_acido"),
]

# ESTRUCTURAS: (x, y, imagen). Decorado de atras.
ESTRUCTURAS = [
    (200, 600, "andamio_torre"),
    (960, 600, "viga_vertical_alta"),
    (1720, 600, "escalera_metal"),
    (2480, 600, "viga_vertical_01"),
    (3240, 600, "viga_vertical_02"),
    (4000, 600, "andamio_torre"),
    (4760, 600, "viga_vertical_alta"),
    (5520, 600, "escalera_metal"),
    (6280, 600, "viga_vertical_01"),
    (7040, 600, "viga_vertical_02"),
]

# OBJETOS: (x, altura de la superficie, imagen).
OBJETOS = [
    (16, 560, "barril_oxidado"),
    (547, 530, "letrero_h2o_company"),
    (989, 560, "llantas_apiladas"),
    (1507, 500, "barriles_apilados"),
    (2031, 540, "senal_advertencia_triangulo"),
    (2361, 560, "conos_trafico"),
    (2892, 510, "letrero_agua_contaminada"),
    (3334, 560, "valla_metal"),
    (3852, 530, "barril_verde_contaminado"),
    (4376, 560, "generador_electrico"),
    (4706, 500, "senal_hombres_trabajando"),
    (5237, 540, "barrera_concreto_rayada"),
    (5679, 560, "cajas_madera_y_caja_h2o"),
    (6197, 520, "letrero_obra_flecha"),
    (6721, 560, "barril_oxidado"),
    (7051, 540, "letrero_h2o_company"),
]

# OBREROS: (x, limite izquierdo, limite derecho)
OBREROS = [
    (1718, 1546, 1890),
    (3062, 2931, 3193),
    (4490, 4415, 4565),
    (5887, 5718, 6056),
    (7265, 7090, 7441),
]

# GOTAS: (x, y)
GOTAS = [
    (138, 502), (253, 502), (368, 502), (661, 472), (791, 472),
    (1107, 502), (1219, 502), (1331, 502), (1627, 442), (1740, 442),
    (1854, 442), (2106, 482), (2197, 482), (2483, 502), (2598, 502),
    (2713, 502), (3006, 452), (3136, 452), (3452, 502), (3564, 502),
    (3676, 502), (3972, 472), (4085, 472), (4199, 472), (4451, 502),
    (4542, 502), (4828, 442), (4943, 442), (5058, 442), (5351, 482),
    (5481, 482), (5797, 502), (5909, 502), (6021, 502), (6317, 462),
    (6430, 462), (6544, 462), (6796, 502), (6887, 502), (7173, 482),
    (7288, 482), (7403, 482), (496, 380), (1456, 350), (2310, 390),
    (3283, 360), (4325, 380), (5186, 350), (6146, 370), (7000, 390),
]

# ---------------------------------------------------------------------------
# PELEA FINAL
# ---------------------------------------------------------------------------
# La arena del jefe se deja ANTES del final del mapa para que la camara
# pueda centrarse en la pelea. Si se pone pegada al borde, el protagonista
# queda siempre en la orilla de la pantalla y no se ve bien.
ARENA_IZQUIERDA = 7300
ARENA_DERECHA = 8640
JEFE_X = 7800

DIALOGO_INICIO = (
    ("corvo", "CORVO", "Es aquí. De esta planta salió todo."),
    ("corvo", "CORVO", "La H2O Company. Embotellan el agua que le quitan al pueblo."),
    ("heroe", "", "Entonces el río no se secó solo. Se lo llevaron."),
    ("corvo", "CORVO", "Hoy peleamos los dos. Ya no vas solo."),
    ("corvo", "CORVO", "Cuidado con las fugas y los charcos: todo aquí quema."),
    ("heroe", "", "Vamos por el que da las órdenes."),
)

# Lo que dice el empresario cuando lo ven por primera vez.
# Sus argumentos son BUENOS a proposito: si fuera un villano tonto, el
# mensaje del juego no serviria de nada.
DIALOGO_JEFE = (
    ("jefe", "EL EMPRESARIO", "Así que ustedes son los que entraron a mi planta."),
    ("jefe", "EL EMPRESARIO", "Déjame adivinar: vienen a salvar el agua."),
    ("heroe", "", "Vengo a que deje de robársela a mi pueblo."),
    ("jefe", "EL EMPRESARIO", "¿Robar? Yo le doy trabajo a cuatro mil familias."),
    ("jefe", "EL EMPRESARIO", "Sin esta planta no hay medicinas, ni hospitales."),
    ("jefe", "EL EMPRESARIO", "Ni la computadora en la que tus amigos juegan."),
    ("jefe", "EL EMPRESARIO", "El progreso siempre cuesta. Siempre ha costado."),
    ("jefe", "EL EMPRESARIO", "Alguien tiene que tomar las decisiones difíciles."),
    ("corvo", "CORVO", "Yo vengo de tu futuro. Déjame contarte cómo acaba."),
    ("corvo", "CORVO", "Tu planta sigue ahí. Vacía. No queda agua que embotellar."),
    ("heroe", "", "El agua no es como el dinero. No se imprime más."),
    ("heroe", "", "Es el único recurso que no se puede fabricar."),
    ("jefe", "EL EMPRESARIO", "Palabras bonitas. El mundo funciona con otra cosa."),
    ("heroe", "", "Entonces esto lo vamos a discutir de otra forma."),
)

# Cuando se le cae la mascara: la revelacion.
DIALOGO_MASCARA = (
    ("heroe", "", "La máscara... se le cayó."),
    ("heroe", "", "No... no puede ser. ¿Papá?"),
    ("padre", "TU PADRE", "No tenías que verme así."),
    ("heroe", "", "Nos dijiste que te ibas a trabajar lejos."),
    ("heroe", "", "Que era por nosotros."),
    ("padre", "TU PADRE", "Y lo era. Todo lo que hice fue por ustedes."),
    ("padre", "TU PADRE", "Por un bien mayor. Por un futuro mejor para todos."),
    ("heroe", "", "¿Mejor para quién?"),
    ("heroe", "", "Mi hermanita lleva tres días sin tomar agua."),
    ("heroe", "", "No nos faltó dinero, papá. Nos faltaste tú."),
    ("heroe", "", "Y nos faltó lo único que no se compra."),
    ("padre", "TU PADRE", "Yo... pensé que estaba haciendo lo correcto."),
    ("corvo", "CORVO", "Casi todos los que arruinan algo lo creen."),
    ("padre", "TU PADRE", "No voy a parar ahora. No después de todo esto."),
    ("heroe", "", "Entonces voy a tener que detenerte yo."),
)

# Cuando lo derrotan: el cierre.
DIALOGO_FINAL = (
    ("padre", "TU PADRE", "Ya no puedo más..."),
    ("padre", "TU PADRE", "¿De verdad crees que se puede arreglar?"),
    ("heroe", "", "No sé si se pueda arreglar todo. Pero se puede empezar."),
    ("heroe", "", "Lo mejor que podemos hacer es cuidar lo que todavía tenemos."),
    ("heroe", "", "Limpiar lo que ensuciamos. Cerrar la llave. Reparar las fugas."),
    ("heroe", "", "No tirar nada al drenaje. Enseñarle a los que vienen."),
    ("heroe", "", "No se trata de dejar de avanzar, papá."),
    ("heroe", "", "Se trata de avanzar sin quedarnos sin con qué vivir."),
    ("padre", "TU PADRE", "Tu mamá diría exactamente lo mismo."),
    ("padre", "TU PADRE", "Voy a cerrar la planta. Y voy a volver a casa."),
    ("heroe", "", "Juntos vamos a lograr un futuro mejor."),
    ("corvo", "CORVO", "Mira el agua, muchacho. Está volviendo."),
)


class Nivel3(NivelBase):
    MUSICA = "3_final"
    ROTULO = "NIVEL 3  ·  LA PLANTA DE LA H2O COMPANY"
    LARGO = LARGO
    SUELO_Y = 560
    INICIO_X = 120
    DIALOGO_INICIO = DIALOGO_INICIO

    # -- construccion del mapa ------------------------------------------
    def construir(self):
        self.piso = []
        for x, y, nombre in PLATAFORMAS:
            img = recursos.imagen("nivel3", nombre)
            self.piso.append((x, y, img))
            self.solidos.append(recursos.caja_de_piso("nivel3", nombre, x, y, 300))
            self.puntos_seguros.append(x + 70)

        for x, y, nombre in ALTAS:
            img = recursos.imagen("nivel3", nombre)
            izq, der = recursos.borde_pisable("nivel3", nombre)
            self.plataformas.append(
                (pygame.Rect(x + izq, y, der - izq, 22), img, y))

        for x, nombre in PELIGROS:
            img = recursos.imagen("nivel3", nombre)
            ancho, alto = img.get_size()
            y = self.superficie(x) - alto + 8
            caja = pygame.Rect(x + 26, y + alto // 2, ancho - 52, alto // 2)
            self.peligros.append(Peligro(caja, img, x, y))

        for x, y, nombre in ESTRUCTURAS:
            img = recursos.imagen("nivel3", nombre)
            self.adornos_atras.append((x, y - img.get_height(), img))

        for x, y, nombre in OBJETOS:
            img = recursos.imagen("nivel3", nombre)
            self.adornos_atras.append((x, y - img.get_height() + 8, img))

        # el piso de la planta esta inundado de quimicos
        self.agua.append((pygame.Rect(0, PISO_TOXICO + 30, LARGO, 300), None))

        self.img_charco = recursos.imagen("nivel3", "charco_lodo_grande")
        # El panorama mide 3744 px y el nivel 9100. Moviendose a 0.30 cubre
        # todo el recorrido sin repetirse, y el edificio de la H2O Company
        # queda justo detras de la pelea con el jefe final.
        self.img_panorama = recursos.imagen("nivel3", "panorama")

        self.puntos_seguros = sorted(set(self.puntos_seguros))

        self.jefe_aparecio = False
        self.presentacion = False
        self.escena = 0
        self.reloj_escena = 0
        self.mascara_contada = False
        self.esperando_mascara = False
        self.humo = [[x, random.uniform(0, 200)]
                     for x in range(300, LARGO, 900)]

    @staticmethod
    def superficie(x):
        for px, py, nombre in PLATAFORMAS:
            izq, der = recursos.borde_pisable("nivel3", nombre)
            if px + izq <= x <= px + der:
                return py
        return 560

    # Tres clases de enemigo, para que el recorrido no se sienta repetido.
    # (paquete, proyectil, escala del proyectil, es_persona)
    #
    # Los obreros y los policias son PERSONAS: cuando se les acaba la vida
    # NO caen, se asustan y salen corriendo. Aqui no se derrota a nadie, se
    # les quita las ganas de seguir. El robot si es una maquina y cae.
    TIPOS = [
        ("hazmat", "barril_verde_contaminado", 0.55, True),
        ("policia", "garrafon_h2o_chico", 0.6, True),
        ("robot", "charco_agua_contaminada", 0.3, False),
    ]

    def crear_enemigos(self):
        enemigos = []
        for i, (x, izq, der) in enumerate(OBREROS):
            paquete, proyectil, escala, persona = self.TIPOS[i % len(self.TIPOS)]
            enemigo = Enemigo(x, self.superficie(x), izq, der,
                              paquete=paquete, proyectil=proyectil,
                              es_persona=persona)
            enemigo.carpeta_proyectil = "nivel3"
            enemigo.escala_proyectil = escala
            enemigos.append(enemigo)
        return enemigos

    def lista_gotas(self):
        return GOTAS

    # -- el jefe --------------------------------------------------------
    def revisar_jefe(self):
        if self.jefe_aparecio:
            return
        if self.jugador.rect.centerx <= ARENA_IZQUIERDA:
            return

        if not self.presentacion:
            self.presentacion = True
            self.jefe = JefeEmpresario(JEFE_X, self.SUELO_Y,
                                       ARENA_IZQUIERDA, ARENA_DERECHA,
                                       escala=cfg.ESCALA_JEFE_FINAL)
            self.jefe.despierto = False
            self.dialogo = Dialogo(DIALOGO_JEFE, self.personaje)
            self.jugador.vx = 0.0
            self.jugador.mirando = 1
            return

        self.dialogo = None
        self.jefe_aparecio = True
        self.jefe.despierto = True
        self.temblor = 40
        self.aviso = ["¡POR EL AGUA DE TODOS!", 150]

    def actualizar_extra(self):
        # A la mitad de la vida se le cae la mascara.
        #
        # Primero se ve LA MASCARA ROMPERSE COMPLETA (self.jefe.rompiendo),
        # y solo cuando termina esa animacion arranca el dialogo. Si el
        # dialogo saliera antes, el protagonista diria "se le cayo" sin que
        # el jugador lo hubiera visto caer.
        if (self.jefe is not None and self.jefe.acaba_de_romper
                and not self.mascara_contada):
            self.jefe.acaba_de_romper = False
            self.esperando_mascara = True
            self.temblor = 44
            self.proyectiles.clear()
            self.bolas.clear()
            self.jugador.vx = 0.0

        if (self.esperando_mascara and self.jefe is not None
                and self.jefe.rompiendo <= 0):
            self.esperando_mascara = False
            self.mascara_contada = True
            self.dialogo = Dialogo(DIALOGO_MASCARA, self.personaje)

        for nube in self.humo:
            nube[1] += 0.7
            if nube[1] > 260:
                nube[1] = 0

    def al_vencer_jefe(self):
        """Cae derrotado y se queda llorando: aqui empieza el cierre."""
        self.temblor = 50
        self.proyectiles.clear()
        self.bolas.clear()
        self.cerrar_dialogos()
        self.jugador.intocable = True
        self.jugador.invulnerable = 0
        if not self.jugador.en_suelo or self.jugador.rect.top > cfg.ALTO:
            self.plantar_en_suelo(self.jugador)
        self.cinematica = "cierre"
        self.escena = 0
        self.reloj_escena = 80

    # -- la escena final -------------------------------------------------
    def actualizar_cinematica(self):
        if self.temblor > 0:
            self.temblor -= 1
        self.jugador.actualizar(self)
        self.corvo.actualizar(self.jugador)
        if self.jefe:
            self.jefe.actualizar(self, self.jugador)

        # ESCENA 0: el empresario termina de caer
        if self.escena == 0:
            self.reloj_escena -= 1
            if self.reloj_escena <= 0:
                if self.jefe:
                    self.jefe.llorar()
                self.escena = 1
                self.dialogo_final = Dialogo(DIALOGO_FINAL, self.personaje)

        # ESCENA 1: la conversacion del cierre
        elif self.escena == 1:
            self.dialogo_final.actualizar()
            if not self.dialogo_final.activo:
                self.escena = 2
                self.reloj_escena = 0

        # ESCENA 2: el padre se queda ahi, llorando, y el protagonista se
        # le acerca. No desaparece: se quedan juntos un rato antes de que
        # la pantalla se apague.
        elif self.escena == 2:
            self.reloj_escena += 1
            if self.jefe is not None:
                destino = self.jefe.rect.centerx - 110
                if self.caminar_hasta(destino, 2.2) or self.reloj_escena > 240:
                    self.jugador.mirando = (
                        1 if self.jefe.rect.centerx > self.jugador.rect.centerx
                        else -1)
            if self.reloj_escena > 220:
                self.fundido += 4
                if self.fundido >= 255:
                    self.terminado = True
                    self.resultado = "ganado"

        self.mover_camara()

    # -- dibujo ----------------------------------------------------------
    def dibujar_fondo(self, pantalla, cx, cy):
        pantalla.fill((118, 96, 86))
        pantalla.blit(self.img_panorama, (-int(cx * 0.30), -48 - int(cy * 0.2)))

        # columnas de humo que suben de la planta
        for x, altura in self.humo:
            px = x - int(cx * 0.3)
            px %= (cfg.ANCHO + 600)
            px -= 300
            alfa = max(0, min(90, int(90 * (1 - altura / 260.0))))
            if alfa <= 0:
                continue
            radio = 40 + int(altura * 0.35)
            nube = pygame.Surface((radio * 2, radio * 2), pygame.SRCALPHA)
            pygame.draw.circle(nube, (70, 62, 70, alfa), (radio, radio), radio)
            pantalla.blit(nube, (px - radio, 420 - int(altura) - radio))

    def dibujar_terreno(self, pantalla, cx, cy):
        # el lodo quimico del piso de la planta
        arriba = PISO_TOXICO - cy
        pygame.draw.rect(pantalla, (62, 58, 34),
                         (0, arriba, cfg.ANCHO, cfg.ALTO - arriba + 200))
        ancho = self.img_charco.get_width()
        x = -(int(cx * 0.9) % ancho) - ancho
        while x < cfg.ANCHO:
            pantalla.blit(self.img_charco, (x, arriba - 20))
            x += ancho

        tiempo = pygame.time.get_ticks() * 0.0015
        puntos = [(x, arriba + 3 * math.sin((x + cx) * 0.03 + tiempo * 2))
                  for x in range(0, cfg.ANCHO + 10, 10)]
        if len(puntos) > 1:
            pygame.draw.lines(pantalla, (150, 170, 80), False, puntos, 3)

        for x, y, img in self.piso:
            if -700 < x - cx < cfg.ANCHO + 700:
                pantalla.blit(img, (x - cx, y - cy))

    def dibujar_extra(self, pantalla, cx, cy):
        pass
