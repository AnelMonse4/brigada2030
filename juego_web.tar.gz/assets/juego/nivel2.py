# -*- coding: utf-8 -*-
"""
NIVEL 2 - EL FUTURO CONTAMINADO (ano 2030)

El pozo escupe al protagonista en un Irapuato arrasado: el rio toxico corre
por TODO el piso, las plataformas son columnas de fabrica y hay bombas, botes
radiactivos y basura por todas partes. Corvo vuela a su lado.

Al final espera el JEFE DE BASURA. Es demasiado para el protagonista: lo
derriba, y Corvo tiene que cargarlo y sacarlo volando de ahi.

Este nivel esta armado como en la imagen de referencia 01_final.png:
NO hay piso seguro continuo. Todo el suelo es rio toxico y se avanza
saltando de columna en columna.
"""
import math
import random

import pygame

from . import ajustes as cfg
from . import recursos
from .nivel import NivelBase, Dialogo, tapizar_espejo
from .entidades import Enemigo, Bomba, Peligro


LARGO = 9000
RIO_Y = 636               # el rio toxico cubre todo el piso

# Ancho de cada imagen de plataforma (lo fija herramientas/preparar_imagenes.py)
ANCHOS = {
    "plataforma": 300, "plataforma_corta": 180, "plataforma_larga": 440,
    "plataforma_b": 260, "plataforma_c": 240, "plataforma_d": 220,
    "plataforma_e": 240,
}


# ---------------------------------------------------------------------------
# COLUMNAS: (x, altura de la superficie, imagen).
# Son los bloques sobre los que se camina. Entre ellos solo hay rio toxico.
# ---------------------------------------------------------------------------
# COLUMNAS: (x, altura de la superficie, imagen).
# Son los bloques sobre los que se camina. Entre ellos solo hay rio
# toxico. Generado por herramientas/rearmar_nivel2.py.
# COLUMNAS: (x, altura de la superficie, imagen).
# Son los bloques sobre los que se camina. Entre ellos solo hay rio
# toxico. Generado por herramientas/rearmar_nivel2.py.
# COLUMNAS: (x, altura de la superficie, imagen).
# Son los bloques sobre los que se camina. Entre ellos solo hay rio
# toxico. Generado por herramientas/rearmar_nivel2.py.
# COLUMNAS: (x, altura de la superficie, imagen).
# Generado por herramientas/rearmar_nivel2.py, que las coloca
# midiendo el piso REAL de cada dibujo.
# COLUMNAS: (x, altura de la superficie, imagen).
# Generado por herramientas/rearmar_nivel2.py, que las coloca
# midiendo el piso REAL de cada dibujo.
# COLUMNAS: (x, altura de la superficie, imagen).
# Generado por herramientas/rearmar_nivel2.py, que las coloca
# midiendo el piso REAL de cada dibujo.
# COLUMNAS: (x, altura de la superficie, imagen).
# Generado por herramientas/rearmar_nivel2.py, que las coloca
# midiendo el piso REAL de cada dibujo.
# COLUMNAS: (x, altura de la superficie, imagen).
# Generado por herramientas/rearmar_nivel2.py, que las coloca
# midiendo el piso REAL de cada dibujo.
# COLUMNAS: (x, altura de la superficie, imagen).
# Generado por herramientas/rearmar_nivel2.py, que las coloca
# midiendo el piso REAL de cada dibujo.
# COLUMNAS: (x, altura de la superficie, imagen).
# Generado por herramientas/rearmar_nivel2.py, que las coloca
# midiendo el piso REAL de cada dibujo.
# COLUMNAS: (x, altura de la superficie, imagen).
# Generado por herramientas/rearmar_nivel2.py, que las coloca
# midiendo el piso REAL de cada dibujo.
# COLUMNAS: (x, altura de la superficie, imagen).
# Generado por herramientas/rearmar_nivel2.py, que las coloca
# midiendo el piso REAL de cada dibujo.
# COLUMNAS: (x, altura de la superficie, imagen).
# Generado por herramientas/rearmar_nivel2.py, que las coloca
# midiendo el piso REAL de cada dibujo.
COLUMNAS = [
    (0, 580, "plataforma_larga"),
    (504, 560, "plataforma_b"),
    (832, 520, "plataforma_larga"),
    (1336, 580, "plataforma_b"),
    (1664, 540, "plataforma_larga"),
    (2168, 580, "plataforma_b"),
    (2496, 520, "plataforma_larga"),
    (3000, 580, "plataforma_b"),
    (3328, 540, "plataforma_larga"),
    (3832, 580, "plataforma_b"),
    (4160, 520, "plataforma_larga"),
    (4664, 580, "plataforma_b"),
    (4992, 540, "plataforma_larga"),
    (5496, 580, "plataforma_b"),
    (5824, 520, "plataforma_larga"),
    (6328, 580, "plataforma_b"),
    (6656, 540, "plataforma_larga"),
    (7160, 580, "plataforma_b"),
    (7488, 560, "plataforma_larga"),
    (7992, 560, "plataforma_b"),
    (8260, 560, "plataforma_larga"),
    (8640, 560, "plataforma_larga"),
]

# Plataformas altas de paso: (x, y, imagen). Ruta opcional.
ALTAS = [
    (381, 420, "plataforma_corta"),
    (1213, 380, "plataforma_corta"),
    (2045, 400, "plataforma_corta"),
    (2877, 380, "plataforma_corta"),
    (3709, 400, "plataforma_corta"),
    (4541, 380, "plataforma_corta"),
    (5373, 400, "plataforma_corta"),
    (6205, 380, "plataforma_corta"),
    (7037, 400, "plataforma_corta"),
    (7869, 420, "plataforma_corta"),
]

# Puas: (x, imagen). Al centro del piso.
PUAS = [
    (996, "puas"),
    (3502, "puas_b"),
    (5988, "puas"),
]

# Obstaculos que HACEN DANO al tocarlos: (x, imagen).
OBSTACULOS = [
    (2540, "toxico"),
    (5039, "bote"),
    (7511, "charco_toxico"),
]

# Tanques verdes que EXPLOTAN al tocarlos. Un disparo de lejos los revienta.
BOMBAS = [
    2758,
    5254,
    7750,
]

# Techos de puas: (x, y). Cuelgan arriba; por debajo se pasa bien.
TECHOS_PUAS = [
    (1733, 445),
    (4229, 425),
    (6725, 445),
]

# Decoracion sin peligro: (x, altura de la superficie, imagen)
DECORACION = [
    (16, 580, "senaletica"),
    (520, 560, "llanta"),
    (848, 520, "cubo"),
    (1352, 580, "humo"),
    (1680, 540, "caja_fuerte"),
    (2184, 580, "fuente"),
    (2512, 520, "fuente_b"),
    (3016, 580, "senaletica"),
    (3344, 540, "llanta"),
    (3848, 580, "cubo"),
    (4176, 520, "humo"),
    (4680, 580, "caja_fuerte"),
    (5008, 540, "fuente"),
    (5512, 580, "fuente_b"),
    (5840, 520, "senaletica"),
    (6344, 580, "llanta"),
    (6672, 540, "cubo"),
    (7176, 580, "humo"),
    (7504, 560, "caja_fuerte"),
    (8008, 560, "fuente"),
]

# Enemigos: (x, limite izquierdo, limite derecho).
ENEMIGOS = [
    (1467, 1388, 1546),
    (3131, 3052, 3210),
    (4795, 4716, 4874),
    (6459, 6380, 6538),
    (8123, 8044, 8202),
]

# Gotas de agua para recolectar
GOTAS = [
    (110, 520), (219, 520), (327, 520), (583, 500), (686, 500),
    (942, 460), (1051, 460), (1159, 460), (1415, 520), (1518, 520),
    (1774, 480), (1883, 480), (1991, 480), (2247, 520), (2350, 520),
    (2606, 460), (2715, 460), (2823, 460), (3079, 520), (3182, 520),
    (3438, 480), (3547, 480), (3655, 480), (3911, 520), (4014, 520),
    (4270, 460), (4379, 460), (4487, 460), (4743, 520), (4846, 520),
    (5102, 480), (5211, 480), (5319, 480), (5575, 520), (5678, 520),
    (5934, 460), (6043, 460), (6151, 460), (6407, 520), (6510, 520),
    (6766, 480), (6875, 480), (6983, 480), (7239, 520), (7342, 520),
    (7598, 500), (7707, 500), (7815, 500), (8071, 500), (8174, 500),
    (431, 370), (511, 370), (1263, 330), (1343, 330), (2095, 350),
    (2175, 350), (2927, 330), (3007, 330), (3759, 350), (3839, 350),
    (4591, 330), (4671, 330), (5423, 350), (5503, 350), (6255, 330),
    (6335, 330), (7087, 350), (7167, 350), (7919, 370), (7999, 370),
]

# Burbujas radiactivas que suben del rio
BURBUJAS = [200, 1032, 1864, 2696, 3528, 4360, 5192, 6024, 6856, 7688]

JEFE_X = 8600
ARENA_IZQUIERDA = 8260
ARENA_DERECHA = LARGO - 60

DIALOGO_INICIO = (
    ("corvo", "CORVO", "Bienvenido al año 2030. Así quedó Irapuato."),
    ("corvo", "CORVO", "Las fábricas tiraron sus desechos al drenaje durante años."),
    ("heroe", "", "El río... ya no es río. Es veneno corriendo."),
    ("corvo", "CORVO", "No toques el agua. Ya no perdona."),
    ("corvo", "CORVO", "Salta de columna en columna y junta cada gota limpia."),
    ("corvo", "CORVO", "Al final del camino hay algo muy grande. Ten cuidado."),
)

DIALOGO_FINAL = (
    ("heroe", "", "Es... demasiado grande. No puedo contra él."),
    ("corvo", "CORVO", "No te levantes. Esta pelea no era para ganarla."),
    ("corvo", "CORVO", "¡Te tengo! ¡Sujétate fuerte!"),
    ("corvo", "CORVO", "Volvamos al presente, donde todavía hay algo que salvar."),
    ("heroe", "", "Si el agua se cuida hoy, este futuro nunca va a existir."),
)


class Nivel2(NivelBase):
    MUSICA = "2_desarrollo"
    ROTULO = "NIVEL 2  -  EL FUTURO CONTAMINADO"
    LARGO = LARGO
    SUELO_Y = 580
    INICIO_X = 120
    DIALOGO_INICIO = DIALOGO_INICIO

    # -- construccion del mapa ------------------------------------------
    def construir(self):
        self.columnas = []
        for x, y, nombre in COLUMNAS:
            img = recursos.imagen("nivel", nombre)
            self.columnas.append((x, y, img))
            # la caja se ajusta al dibujo real, no al ancho de la imagen:
            # la pieza "plataforma" tenia 99 px de aire a la derecha y el
            # jugador caminaba sobre la nada antes de caerse
            self.solidos.append(recursos.caja_de_piso("nivel", nombre, x, y))
            self.puntos_seguros.append(x + 50)

        for x, y, nombre in ALTAS:
            img = recursos.imagen("nivel", nombre)
            izq, der = recursos.borde_pisable("nivel", nombre)
            self.plataformas.append(
                (pygame.Rect(x + izq, y, der - izq, 22), img, y))

        for x, nombre in PUAS:
            img = recursos.imagen("nivel", nombre)
            ancho, alto = img.get_size()
            y = self.superficie(x) - alto + 4
            # La zona que hace dano es mas angosta que el dibujo: las puntas
            # de las orillas son solo decoracion. Asi rozar el borde no
            # castiga, que era lo que hacia sentir injustas las puas.
            caja = pygame.Rect(x + 24, y + alto // 2, ancho - 48, alto // 2)
            self.peligros.append(Peligro(caja, img, x, y))

        # OBSTACULOS (bote rojo, bidon toxico, charco...).
        # Son SOLIDOS pero NO hacen dano: solo estorban y hay que saltarlos.
        #
        # En este juego solo lastiman cuatro cosas: los enemigos, las puas,
        # las bombas verdes y el agua. Todo lo demas es obstaculo o adorno.
        # Asi el jugador siempre sabe que es peligroso con solo verlo.
        for x, nombre in OBSTACULOS:
            img = recursos.imagen("nivel", nombre)
            ancho, alto = img.get_size()
            y = self.superficie(x) - alto + 6
            self.solidos.append(
                pygame.Rect(x + 12, y + alto // 4, ancho - 24, alto))
            self.adornos_atras.append((x, y, img))

        # Techos de puas: cuelgan arriba. Solo pican la parte de abajo,
        # que es donde estan las puntas; por debajo se pasa caminando.
        img_techo = recursos.imagen("nivel", "puas_techo")
        alto_techo = img_techo.get_height()
        for x, puntas in TECHOS_PUAS:
            # en los datos viene la altura de las PUNTAS; de ahi se saca
            # donde va la esquina del dibujo
            y = puntas - alto_techo
            caja = pygame.Rect(x + 20, puntas - alto_techo // 2,
                               img_techo.get_width() - 40, alto_techo // 2)
            self.peligros.append(Peligro(caja, img_techo, x, y))

        # Tanques verdes que explotan
        self.bombas = [Bomba(x, self.superficie(x) + 4) for x in BOMBAS]

        for x, y, nombre in DECORACION:
            img = recursos.imagen("nivel", nombre)
            self.adornos_atras.append((x, y - img.get_height() + 8, img))

        # el rio toxico cubre TODO el piso del nivel
        self.agua.append((pygame.Rect(0, RIO_Y + 20, LARGO, 300), None))

        self.img_rio = recursos.imagen("nivel", "rio_toxico")
        self.img_cielo = recursos.imagen("nivel", "fondo_toxico")
        # siempre va sobre el color liso del cielo: se aplana (mas rapido)
        self.img_paisaje = recursos.aplanar(recursos.imagen("nivel", "fondo_paisaje"),
                                            (42, 24, 38))
        # La bruma verde: antes se pintaba encima de toda la pantalla en cada
        # cuadro. Ahora se "tine" una sola vez cada capa del fondo: se ve
        # igual y en el celular cuesta muchisimo menos.
        BRUMA = ((60, 140, 50), 38)
        self.color_cielo = recursos.tenir(
            recursos.aplanar(pygame.Surface((1, 1)), (42, 24, 38)), *BRUMA).get_at((0, 0))
        self.img_paisaje = recursos.tenir(self.img_paisaje, *BRUMA)
        self.img_fabrica = recursos.imagen("nivel", "fondo_fabrica")
        self.img_cielo = recursos.tenir(self.img_cielo, *BRUMA)
        self.img_fabrica = recursos.tenir(self.img_fabrica, *BRUMA)
        self.img_bandera = recursos.imagen("nivel", "bandera_meta")
        self.img_burbujas = recursos.imagen("nivel", "burbujas")

        self.burbujas = [[x, random.uniform(0, 200)] for x in BURBUJAS]
        self.puntos_seguros = sorted(set(self.puntos_seguros))

        self.jefe_aparecio = False
        self.escena = 0
        self.reloj_escena = 0

    def crear_enemigos(self):
        return [Enemigo(x, self.superficie(x), izq, der)
                for x, izq, der in ENEMIGOS]

    @staticmethod
    def superficie(x):
        """Altura de la columna que hay debajo de esa posicion."""
        for cx, cy, nombre in COLUMNAS:
            if cx <= x <= cx + ANCHOS.get(nombre, 300):
                return cy
        return 580

    def lista_gotas(self):
        return GOTAS

    # -- el jefe --------------------------------------------------------
    def revisar_jefe(self):
        if self.jefe is None and not self.jefe_aparecio:
            if self.jugador.rect.centerx > ARENA_IZQUIERDA:
                # el jefe no se queda en su arena: persigue por todo el mapa
                self.jefe = Enemigo(JEFE_X, 560, 60, ARENA_DERECHA,
                                    escala=cfg.ESCALA_JEFE, vida=cfg.VIDA_JEFE,
                                    jefe=True)
                self.jefe.titulo = "JEFE DE BASURA"
                self.jefe_aparecio = True
                self.temblor = 44
                self.aviso = ["JEFE DE BASURA", 150]

    def al_vencer_jefe(self):
        """
        El jefe cae, pero de un ultimo golpe derriba al protagonista.
        Corvo baja, lo carga y se lo lleva volando fuera de la pantalla.
        """
        self.temblor = 50
        self.proyectiles.clear()
        self.bolas.clear()
        self.cerrar_dialogos()
        self.jugador.intocable = True
        self.jugador.invulnerable = 0
        # si venia en el aire o cayendose, lo plantamos en suelo firme
        if not self.jugador.en_suelo or self.jugador.rect.top > cfg.ALTO:
            self.plantar_en_suelo(self.jugador)
        self.jugador.derrotado = False
        self.jugador.poner("caido", reiniciar=True)
        self.jugador.vx = 0.0
        self.cinematica = "rescate"
        self.escena = 0
        self.reloj_escena = 60

    def actualizar_cinematica(self):
        if self.temblor > 0:
            self.temblor -= 1

        # ESCENA 0: el protagonista queda tirado en el piso
        if self.escena == 0:
            self.jugador.vy = min(self.jugador.vy + cfg.GRAVEDAD, cfg.CAIDA_MAXIMA)
            self.mover(self.jugador, 0, self.jugador.vy)
            self.jugador.animacion.actualizar()
            self.corvo.actualizar(self.jugador)
            self.reloj_escena -= 1
            if self.reloj_escena <= 0:
                self.escena = 1
                self.dialogo_final = Dialogo(DIALOGO_FINAL, self.personaje)

        # ESCENA 1: los dialogos del rescate
        elif self.escena == 1:
            self.dialogo_final.actualizar()
            self.corvo.actualizar(self.jugador)
            if not self.dialogo_final.activo:
                self.escena = 2
                self.reloj_escena = 0

        # ESCENA 2: Corvo baja hasta el protagonista
        elif self.escena == 2:
            self.reloj_escena += 1
            meta_x = self.jugador.rect.centerx
            meta_y = self.jugador.rect.top - 30
            self.corvo.x += (meta_x - self.corvo.x) * 0.10
            self.corvo.y += (meta_y - self.corvo.y) * 0.10
            self.corvo.poner("volar")
            self.corvo.rect.center = (int(self.corvo.x), int(self.corvo.y))
            self.corvo.animacion.actualizar()
            if abs(self.corvo.x - meta_x) < 16 and self.reloj_escena > 30:
                self.escena = 3
                self.reloj_escena = 0
                self.corvo.llevando = True

        # ESCENA 3: lo carga y los dos salen volando de la pantalla
        elif self.escena == 3:
            self.reloj_escena += 1
            self.corvo.x -= 1.4 + self.reloj_escena * 0.14
            self.corvo.y -= 0.6 + self.reloj_escena * 0.055
            self.corvo.mirando = -1
            self.corvo.poner("mover")
            self.corvo.rect.center = (int(self.corvo.x), int(self.corvo.y))
            self.corvo.animacion.actualizar()
            # el protagonista va colgando justo debajo de Corvo. Se coloca
            # por midbottom porque el dibujo se apoya en la parte de abajo
            # del rect, y con midtop quedaba un hueco entre los dos.
            self.jugador.rect.midbottom = (self.corvo.rect.centerx + 12,
                                           self.corvo.rect.bottom + 40)
            self.jugador.mirando = -1

            fuera = (self.corvo.rect.right - self.camara_x < -160
                     or self.corvo.rect.bottom < -160)
            if fuera or self.reloj_escena > 400:
                self.fundido += 6
                if self.fundido >= 255:
                    self.terminado = True
                    self.resultado = "ganado"

        self.mover_camara()

    def mover_camara(self):
        # durante el vuelo final la camara se queda quieta para que se vea
        # como Corvo se lleva al protagonista fuera de la pantalla
        if self.cinematica == "rescate" and self.escena == 3:
            return
        super().mover_camara()

    # -- cada cuadro -----------------------------------------------------
    def actualizar_extra(self):
        for burbuja in self.burbujas:
            burbuja[1] += 1.1
            if burbuja[1] > 230:
                burbuja[1] = 0

    # -- dibujo ----------------------------------------------------------
    def dibujar_fondo(self, pantalla, cx, cy):
        pantalla.fill(self.color_cielo)

        # EL CIELO: el atardecer con las montañas y las chimeneas, completo.
        # Va de una sola pieza (nada de repetirlo) y casi no se mueve: la
        # imagen mide 1588 px de ancho y a 0.03 alcanza a cubrir los 9000 px
        # del nivel sin tener que repetirse.
        pantalla.blit(self.img_paisaje, (-int(cx * 0.03), -60))

        # Las fabricas van CHICAS y pegadas al piso, como una hilera de
        # naves al fondo. Antes eran tan grandes que tapaban todo el cielo y
        # el atardecer no se veia.
        tapizar_espejo(pantalla, self.img_cielo, cx * 0.22,
                       RIO_Y - self.img_cielo.get_height() + 10)
        tapizar_espejo(pantalla, self.img_fabrica, cx * 0.45,
                       RIO_Y - self.img_fabrica.get_height() + 30)



    def dibujar_terreno(self, pantalla, cx, cy):
        # el rio toxico, que corre por todo el piso
        ancho = self.img_rio.get_width()
        onda = int(5 * math.sin(pygame.time.get_ticks() * 0.0025))
        x = -(cx % ancho) - ancho
        while x < cfg.ANCHO:
            pantalla.blit(self.img_rio, (x, RIO_Y + onda - cy))
            x += ancho
        pygame.draw.rect(pantalla, (46, 96, 30),
                         (0, RIO_Y + 46 - cy, cfg.ANCHO, cfg.ALTO))

        # burbujas radiactivas que suben del veneno
        for bx, altura in self.burbujas:
            px = bx - cx
            if -200 < px < cfg.ANCHO + 200:
                copia = self.img_burbujas.copy()
                copia.set_alpha(max(0, min(255, int(255 * (1 - altura / 230.0)))))
                pantalla.blit(copia, (px, RIO_Y - int(altura) - cy))

        for x, y, img in self.columnas:
            if -600 < x - cx < cfg.ANCHO + 600:
                # la columna se prolonga hacia abajo hasta el rio
                base = y + img.get_height() - 10
                if base < RIO_Y + 40:
                    tubo = pygame.Rect(x + img.get_width() // 2 - 36 - cx,
                                       base - cy, 72, RIO_Y + 40 - base)
                    pygame.draw.rect(pantalla, (44, 52, 46), tubo)
                    pygame.draw.rect(pantalla, (74, 86, 72), (tubo.x, tubo.y, 12, tubo.height))
                    pygame.draw.rect(pantalla, (28, 34, 30),
                                     (tubo.right - 10, tubo.y, 10, tubo.height))
                pantalla.blit(img, (x - cx, y - cy))

    def dibujar_extra(self, pantalla, cx, cy):
        pantalla.blit(self.img_bandera,
                      (ARENA_DERECHA - 150 - cx,
                       560 - self.img_bandera.get_height() + 6 - cy))
