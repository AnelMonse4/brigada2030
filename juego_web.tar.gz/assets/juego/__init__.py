# -*- coding: utf-8 -*-
"""Paquete con todo el codigo del juego."""
