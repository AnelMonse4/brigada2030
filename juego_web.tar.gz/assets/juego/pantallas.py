# -*- coding: utf-8 -*-
"""
Las pantallas que no son de juego: titulo, eleccion de personaje, instrucciones,
pantalla de derrota y pantalla de nivel superado.
"""
import math

import pygame

from . import ajustes as cfg
from . import recursos


def _velo(pantalla, alfa=170, color=cfg.NEGRO):
    capa = pygame.Surface((cfg.ANCHO, cfg.ALTO), pygame.SRCALPHA)
    capa.fill((*color, alfa))
    pantalla.blit(capa, (0, 0))


def _panel(pantalla, rect, alfa=225):
    fondo = pygame.Surface(rect.size, pygame.SRCALPHA)
    fondo.fill((*cfg.PANEL, alfa))
    pantalla.blit(fondo, rect.topleft)
    pygame.draw.rect(pantalla, cfg.BORDE, rect, 3)


# ---------------------------------------------------------------------------
# TITULO
# ---------------------------------------------------------------------------
class Titulo:
    """
    Pantalla de inicio.

    Ademas de "ESPACIO para comenzar", trae tres botoncitos para saltar
    directo a cualquier nivel. Sirven para enseñar el juego sin tener que
    jugarlo completo: en una demostracion se puede ir derecho al nivel que
    se quiera mostrar. Funcionan con el raton y tambien con las teclas
    1, 2 y 3.
    """

    siguiente = "personaje"

    # (destino, letrero, tecla)
    ATAJOS = [
        ("nivel1", "NIVEL 1", pygame.K_1),
        ("nivel2", "NIVEL 2", pygame.K_2),
        ("nivel3", "NIVEL 3", pygame.K_3),
    ]
    ANCHO_BOTON = 104
    ALTO_BOTON = 32
    ALTO_FRANJA = 152        # la franja oscura de abajo

    def __init__(self):
        self.tiempo = 0
        # el video ya trae dibujado el titulo del juego, asi que encima de el
        # solo ponemos el aviso de "presiona espacio"
        self.video = recursos.video("intro", cfg.VIDEO_FPS)
        recursos.musica("1_inicio", 0.4)

    def _cajas(self):
        """
        Donde queda cada botoncito.

        Van centrados en la franja oscura de abajo, no sobre el dibujo del
        titulo: ahi estorbaban y tapaban el nombre del juego.
        """
        cajas = []
        ancho_letrero = 118
        total = ancho_letrero + len(self.ATAJOS) * (self.ANCHO_BOTON + 10) - 10
        x = (cfg.ANCHO - total) // 2 + ancho_letrero
        y = cfg.ALTO - 44
        for destino, letrero, tecla in self.ATAJOS:
            cajas.append((pygame.Rect(x, y, self.ANCHO_BOTON, self.ALTO_BOTON),
                          destino, letrero, tecla))
            x += self.ANCHO_BOTON + 10
        return cajas

    def tecla(self, tecla):
        if tecla in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER):
            return self.siguiente
        for destino, _letrero, atajo in self.ATAJOS:
            if tecla == atajo:
                return destino
        return None

    def raton(self, posicion):
        for caja, destino, _letrero, _tecla in self._cajas():
            if caja.collidepoint(posicion):
                return destino
        return None

    def actualizar(self):
        self.tiempo += 1
        self.video.actualizar(1.0 / cfg.FPS)

    def dibujar(self, pantalla):
        if not self.video.dibujar(pantalla):
            # si por algo no estan los cuadros del video, usamos el fondo fijo
            pantalla.blit(recursos.imagen("nivel", "pozo_seco"), (0, 0))
            _velo(pantalla, 120)
            recursos.texto(pantalla, "BRIGADA 2030", cfg.ANCHO // 2, 150,
                           tamano=78, color=cfg.AGUA, centrado=True, negrita=True)
            recursos.texto(pantalla, "EL POZO DEL TIEMPO", cfg.ANCHO // 2, 240,
                           tamano=40, color=cfg.BLANCO, centrado=True, negrita=True)

        # franja oscura abajo para que se lea todo sobre el video
        franja = pygame.Surface((cfg.ANCHO, self.ALTO_FRANJA), pygame.SRCALPHA)
        franja.fill((*cfg.NEGRO, 165))
        pantalla.blit(franja, (0, cfg.ALTO - self.ALTO_FRANJA))

        if (self.tiempo // 30) % 2 == 0:
            recursos.texto(pantalla, "TOCA LA PANTALLA  para comenzar", cfg.ANCHO // 2,
                           cfg.ALTO - 140, tamano=28, color=cfg.VERDE_TOXICO,
                           centrado=True, negrita=True)
        recursos.texto(pantalla, "Un juego sobre el cuidado del agua  ·  Reto JAPAMI",
                       cfg.ANCHO // 2, cfg.ALTO - 94, tamano=17, color=cfg.BLANCO,
                       centrado=True)

        self._dibujar_atajos(pantalla)

    def _dibujar_atajos(self, pantalla):
        """Los botoncitos de arriba a la derecha para ir directo a un nivel."""
        raton = pygame.mouse.get_pos()
        cajas = self._cajas()

        primera = cajas[0][0]
        recursos.texto(pantalla, "IR DIRECTO A:", primera.left - 59,
                       primera.y + 8, tamano=15, color=cfg.GRIS, centrado=True)

        for i, (caja, _destino, letrero, _tecla) in enumerate(cajas):
            encima = caja.collidepoint(raton)
            fondo = pygame.Surface(caja.size, pygame.SRCALPHA)
            fondo.fill((*cfg.PANEL, 245 if encima else 195))
            pantalla.blit(fondo, caja.topleft)
            pygame.draw.rect(pantalla, cfg.AGUA if encima else cfg.BORDE, caja, 2)
            recursos.texto(pantalla, letrero, caja.centerx, caja.y + 7,
                           tamano=17,
                           color=cfg.BLANCO if encima else (205, 205, 215),
                           centrado=True, negrita=encima)
            # el numero de tecla, chiquito en la esquina
            recursos.texto(pantalla, str(i + 1), caja.right - 11, caja.y + 1,
                           tamano=11, color=cfg.VERDE_TOXICO, sombra=False)


# ---------------------------------------------------------------------------
# ELEGIR PERSONAJE
# ---------------------------------------------------------------------------
# Los dos protagonistas: (clave interna, nombre, frase, animacion de reposo)
OPCIONES = [
    ("aqua", "AQUA", "Lanza bolas de agua", "idle_quieto"),
    ("yani", "YANI", "Lanza bolas de agua", "idle_quieto"),
]


class ElegirPersonaje:
    def __init__(self):
        self.tiempo = 0
        self.seleccion = 0
        self.elegido = None          # lo lee main.py para arrancar el nivel

    def tecla(self, tecla):
        if tecla in (pygame.K_LEFT, pygame.K_a):
            self.seleccion = 0
        elif tecla in (pygame.K_RIGHT, pygame.K_d):
            self.seleccion = 1
        elif tecla in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER):
            self.elegido = OPCIONES[self.seleccion][0]
            return "tutorial"
        return None

    def actualizar(self):
        self.tiempo += 1

    def dibujar(self, pantalla):
        pantalla.blit(recursos.imagen("nivel", "pozo_seco"), (0, 0))
        _velo(pantalla, 185)

        recursos.texto(pantalla, "ELIGE A TU PROTAGONISTA", cfg.ANCHO // 2, 70,
                       tamano=40, color=cfg.AGUA, centrado=True, negrita=True)

        flote = int(6 * math.sin(self.tiempo * 0.06))
        # los dos personajes se mueven en su pose de reposo
        for i, (clave, nombre, frase, _reposo) in enumerate(OPCIONES):
            elegido = (self.seleccion == i)
            caja = pygame.Rect(180 + i * 540, 180, 380, 420)
            _panel(pantalla, caja, 235 if elegido else 150)
            if elegido:
                pygame.draw.rect(pantalla, cfg.AGUA, caja.inflate(14, 14), 4)

            cuadros = recursos.animaciones()[clave]["quieto"]
            cuadro = cuadros[(self.tiempo // 8) % len(cuadros)]
            sprite = recursos.escalar(cuadro, 1.9)
            if not elegido:
                sprite = sprite.copy()
                sprite.set_alpha(140)
            pantalla.blit(sprite, (caja.centerx - sprite.get_width() // 2,
                                   caja.bottom - sprite.get_height() - 90 +
                                   (flote if elegido else 0)))

            recursos.texto(pantalla, nombre, caja.centerx, caja.bottom - 76,
                           tamano=34, color=cfg.BLANCO if elegido else cfg.GRIS,
                           centrado=True, negrita=True)
            recursos.texto(pantalla, frase, caja.centerx, caja.bottom - 38,
                           tamano=18, color=cfg.VERDE_TOXICO if elegido else cfg.GRIS,
                           centrado=True)

        # Corvo siempre volando: nunca se usa su cuadro de posado
        aleteo = recursos.animaciones()["corvo"]["volar"]
        corvo = aleteo[(self.tiempo // 5) % len(aleteo)]
        pantalla.blit(corvo, (cfg.ANCHO // 2 - corvo.get_width() // 2, 100 - flote))

        recursos.texto(pantalla, "[ <  > ] cambiar      [ TOCA AL CENTRO ] confirmar",
                       cfg.ANCHO // 2, cfg.ALTO - 90, tamano=22,
                       color=cfg.BLANCO, centrado=True)


# ---------------------------------------------------------------------------
# INSTRUCCIONES
# ---------------------------------------------------------------------------
CONTROLES = [
    ("BOTONES  <  >", "Moverte"),
    ("CORRER", "Mantener para correr"),
    ("SALTAR", "Saltar"),
    ("SALTAR  2 VECES", "Doble salto, en el aire"),
    ("BOTÓN  v", "Agacharte (y avanzar agachado)"),
    ("ATAQUE", "Lanzar bola de agua"),
    ("TOCAR PANTALLA", "Pasar los diálogos"),
    ("", "Puedes tocar dos botones a la vez"),
]

# (titulo, renglones)  -- el panel de la derecha
CONSEJOS = [
    ("CÓMO CONSEGUIR AGUA", [
        "Recoge las gotas del camino.",
        "Derrota enemigos: sueltan agua.",
        "Dispara a las púas y a las bombas:",
        "al romperse también sueltan agua.",
    ]),
    ("QUÉ TE HACE DAÑO", [
        "Solo cuatro cosas:",
        "enemigos, púas, bombas verdes",
        "y el agua sucia.",
        "Llevan una franja amarilla",
        "y negra debajo.",
    ]),
    ("TRUCOS", [
        "Cada 10 gotas ganas un corazón.",
        "Agáchate para pasar por debajo",
        "de las púas que cuelgan.",
        "Revienta las bombas de lejos:",
        "así no te hacen daño.",
    ]),
]


class Instrucciones:
    def __init__(self):
        self.tiempo = 0

    def tecla(self, tecla):
        if tecla in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER):
            return "nivel1"
        return None

    def actualizar(self):
        self.tiempo += 1

    def dibujar(self, pantalla):
        # fondo neutro: la imagen tutorial.jpeg ya trae sus propios textos
        # y se encimaba con estos paneles.
        pantalla.blit(recursos.imagen("nivel", "pozo_seco"), (0, 0))
        _velo(pantalla, 210)

        recursos.texto(pantalla, "CÓMO SE JUEGA", cfg.ANCHO // 2, 24,
                       tamano=38, color=cfg.AGUA, centrado=True, negrita=True)

        # --- columna izquierda: los controles ---
        caja = pygame.Rect(40, 80, 560, 410)
        _panel(pantalla, caja)
        recursos.texto(pantalla, "CONTROLES", caja.centerx, caja.y + 12,
                       tamano=22, color=cfg.AGUA, centrado=True, negrita=True)
        y = caja.y + 52
        for tecla, accion in CONTROLES:
            recursos.texto(pantalla, tecla, caja.x + 22, y, tamano=19,
                           color=cfg.VERDE_TOXICO, negrita=True)
            recursos.texto(pantalla, accion, caja.x + 260, y, tamano=19,
                           color=cfg.BLANCO)
            y += 43

        # --- columna derecha: los consejos ---
        caja = pygame.Rect(624, 80, 616, 410)
        _panel(pantalla, caja)
        y = caja.y + 14
        for titulo, renglones in CONSEJOS:
            recursos.texto(pantalla, titulo, caja.centerx, y, tamano=19,
                           color=cfg.VERDE_TOXICO, centrado=True, negrita=True)
            y += 28
            for renglon in renglones:
                recursos.texto(pantalla, renglon, caja.centerx, y, tamano=17,
                               color=cfg.BLANCO, centrado=True)
                y += 22
            y += 10

        # --- los corazones abajo ---
        corazon = recursos.imagen("hud", "corazon_lleno")
        gota = recursos.imagen("nivel", "gota")
        total = cfg.VIDAS * (corazon.get_width() + 8) + gota.get_width() + 30
        x = cfg.ANCHO // 2 - total // 2
        for i in range(cfg.VIDAS):
            pantalla.blit(corazon, (x, 516))
            x += corazon.get_width() + 8
        pantalla.blit(gota, (x + 24, 510))

        recursos.texto(pantalla,
                       "Tienes %d corazones. Cada golpe te quita uno." % cfg.VIDAS,
                       cfg.ANCHO // 2, 576, tamano=19, color=cfg.BLANCO,
                       centrado=True)
        recursos.texto(pantalla,
                       "Al final de cada nivel hay un jefe.",
                       cfg.ANCHO // 2, 604, tamano=19, color=cfg.BLANCO,
                       centrado=True)

        if (self.tiempo // 30) % 2 == 0:
            recursos.texto(pantalla, "[ TOCA ]  empezar el nivel 1",
                           cfg.ANCHO // 2, 652, tamano=26,
                           color=cfg.VERDE_TOXICO, centrado=True, negrita=True)


# ---------------------------------------------------------------------------
# FIN DE NIVEL
# ---------------------------------------------------------------------------
class FinDeNivel:
    def __init__(self, gano, gotas, total, nivel="nivel2"):
        self.gano = gano
        self.gotas = gotas
        self.total = total
        self.nivel = nivel          # de que nivel venimos
        self.tiempo = 0
        recursos.musica("1_inicio", 0.45)

    def tecla(self, tecla):
        if tecla in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER):
            return "titulo" if self.gano else self.nivel
        return None

    def actualizar(self):
        self.tiempo += 1

    def dibujar(self, pantalla):
        fondo = "pozo_agua" if self.gano else "pozo_seco"
        pantalla.blit(recursos.imagen("nivel", fondo), (0, 0))
        _velo(pantalla, 175)

        if self.gano:
            recursos.texto(pantalla, "NIVEL 2 SUPERADO", cfg.ANCHO // 2, 110,
                           tamano=58, color=cfg.AGUA, centrado=True, negrita=True)
            mensajes = [
                "Corvo te sacó cargando del futuro y volvieron al presente.",
                "Ahora sabes lo que pasa si no cuidamos el agua.",
                "",
                "Cada gota cuenta: cierra la llave, repara las fugas",
                "y nunca tires basura al drenaje.",
            ]
            color_final = cfg.VERDE_TOXICO
            pie = "[ TOCA ]  volver al menú"
        else:
            recursos.texto(pantalla, "TE QUEDASTE SIN AGUA", cfg.ANCHO // 2, 110,
                           tamano=52, color=cfg.ROJO, centrado=True, negrita=True)
            if self.nivel == "nivel1":
                mensajes = [
                    "Los monstruos de basura pudieron contigo esta vez.",
                    "",
                    "Vuelve a intentarlo: esquiva las púas,",
                    "no caigas al río y usa tu bola de agua.",
                ]
                pie = "[ TOCA ]  reintentar el nivel 1"
            elif self.nivel == "nivel3":
                mensajes = [
                    "La planta de la H2O Company te sacó esta vez.",
                    "",
                    "Vuelve a intentarlo: usa el doble salto,",
                    "esquiva las fugas y no pises los charcos.",
                ]
                pie = "[ TOCA ]  reintentar el nivel 3"
            else:
                mensajes = [
                    "El futuro contaminado te venció esta vez.",
                    "",
                    "Vuelve a intentarlo: salta de columna en columna",
                    "y no toques nunca el río tóxico.",
                ]
                pie = "[ TOCA ]  reintentar el nivel 2"
            color_final = cfg.ROJO

        for i, linea in enumerate(mensajes):
            recursos.texto(pantalla, linea, cfg.ANCHO // 2, 220 + i * 38,
                           tamano=24, color=cfg.BLANCO, centrado=True)

        caja = pygame.Rect(cfg.ANCHO // 2 - 270, 450, 540, 90)
        _panel(pantalla, caja)
        gota = recursos.imagen("nivel", "gota")
        pantalla.blit(gota, (caja.x + 40, caja.centery - gota.get_height() // 2))
        recursos.texto(pantalla, "Gotas recuperadas:  %d de %d" % (self.gotas, self.total),
                       caja.x + 100, caja.centery - 14, tamano=24, color=color_final,
                       negrita=True)

        if (self.tiempo // 30) % 2 == 0:
            recursos.texto(pantalla, pie, cfg.ANCHO // 2, cfg.ALTO - 110,
                           tamano=26, color=cfg.BLANCO, centrado=True, negrita=True)


# ---------------------------------------------------------------------------
# TRANSICION ENTRE EL NIVEL 1 Y EL NIVEL 2
#
# El pozo se los tragó. Esta pantalla es el viaje: el destello se apaga, el
# pozo gira en el vacio y el mundo cambia del bosque vivo al futuro muerto.
# Avanza sola; con ESPACIO se la salta.
# ---------------------------------------------------------------------------
class Transicion:
    DURACION = 420            # 7 segundos

    # cada transicion ya suena con la musica del nivel al que lleva
    MUSICA_DESTINO = {"nivel1": "1_inicio", "nivel2": "2_desarrollo",
                      "nivel3": "3_final"}

    def __init__(self, personaje="aqua", destino="nivel2", al_futuro=True):
        self.tiempo = 0
        self.personaje = personaje
        self.destino = destino
        self.al_futuro = al_futuro      # True = 2026 -> 2030, False = al revés
        recursos.musica(self.MUSICA_DESTINO.get(destino, "2_desarrollo"), 0.4)

    def tecla(self, tecla):
        if tecla in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER):
            return self.destino
        return None

    def actualizar(self):
        self.tiempo += 1
        if self.tiempo >= self.DURACION:
            return self.destino
        return None

    def dibujar(self, pantalla):
        t = self.tiempo / float(self.DURACION)

        # el fondo pasa del verde del presente al rojo del futuro
        # (o al reves, si el viaje es de regreso)
        verde = (30, 96, 74)
        rojo = (104, 32, 42)
        desde, hasta = (verde, rojo) if self.al_futuro else (rojo, verde)
        fondo = tuple(int(desde[i] + (hasta[i] - desde[i]) * t) for i in range(3))
        pantalla.fill(fondo)

        centro = (cfg.ANCHO // 2, cfg.ALTO // 2 - 30)

        # anillos que se van abriendo, como el tunel del pozo
        for i in range(7):
            avance = (t * 2.4 + i * 0.16) % 1.0
            radio = int(40 + avance * 620)
            alfa = int(150 * (1 - avance))
            if alfa <= 0:
                continue
            anillo = pygame.Surface((radio * 2 + 8, radio * 2 + 8), pygame.SRCALPHA)
            color = (140, 220, 255) if t < 0.5 else (200, 230, 120)
            pygame.draw.circle(anillo, (*color, alfa),
                               (radio + 4, radio + 4), radio, 5)
            pantalla.blit(anillo, (centro[0] - radio - 4, centro[1] - radio - 4))

        # el pozo girando en medio
        pozo = recursos.imagen("nivel", "pozo")
        escala = 0.75 + 0.35 * math.sin(self.tiempo * 0.045)
        pozo = recursos.escalar(pozo, escala)
        pozo = pozo.copy()
        pozo.set_alpha(max(0, int(255 * (1 - abs(t - 0.5) * 1.5))))
        pantalla.blit(pozo, (centro[0] - pozo.get_width() // 2,
                             centro[1] - pozo.get_height() // 2))

        # los dos viajeros, hechos silueta de luz
        for clave, dx in ((self.personaje, -230), ("corvo", 230)):
            # el protagonista de pie; Corvo volando (nunca posado)
            accion = "volar" if clave == "corvo" else "quieto"
            cuadros = recursos.animaciones()[clave][accion]
            paso = 5 if clave == "corvo" else 7
            img = cuadros[(self.tiempo // paso) % len(cuadros)]
            x = centro[0] + dx - img.get_width() // 2
            y = centro[1] - img.get_height() // 2

            # un resplandor suave detras de cada uno
            halo = pygame.Surface((img.get_width() + 60, img.get_height() + 60),
                                  pygame.SRCALPHA)
            for i in range(8):
                caja = halo.get_rect().inflate(-i * 12, -i * 12)
                pygame.draw.ellipse(halo, (24, 36, 40, 255), caja)
            pantalla.blit(halo, (x - 30, y - 30), special_flags=pygame.BLEND_RGBA_ADD)
            pantalla.blit(img, (x, y))

        # los letreros del viaje
        if self.al_futuro:
            tramos = [("EL POZO DEL TIEMPO", "El agua los está llevando...", cfg.AGUA),
                      ("2026", "Irapuato  ·  adelante en el tiempo", cfg.BLANCO),
                      ("AÑO 2030", "Irapuato, cuatro años después", cfg.VERDE_TOXICO)]
        else:
            tramos = [("DE VUELTA", "Corvo te saca del 2030...", cfg.AGUA),
                      ("2030", "Irapuato  ·  de regreso en el tiempo", cfg.BLANCO),
                      ("AÑO 2026", "Todavía estamos a tiempo", cfg.AGUA)]
        titulo, sub, color = tramos[0 if t < 0.45 else (1 if t < 0.75 else 2)]

        recursos.texto(pantalla, titulo, cfg.ANCHO // 2, 90, tamano=58,
                       color=color, centrado=True, negrita=True)
        recursos.texto(pantalla, sub, cfg.ANCHO // 2, 170, tamano=22,
                       color=cfg.BLANCO, centrado=True)

        # oscurecido al principio y al final, para que empalme con los niveles
        borde = 0
        if t < 0.12:
            borde = int(255 * (1 - t / 0.12))
        elif t > 0.9:
            borde = int(255 * (t - 0.9) / 0.1)
        if borde > 0:
            velo = pygame.Surface((cfg.ANCHO, cfg.ALTO))
            velo.fill(cfg.NEGRO)
            velo.set_alpha(min(255, borde))
            pantalla.blit(velo, (0, 0))

        recursos.texto(pantalla, "[TOCA] saltar", cfg.ANCHO - 200,
                       cfg.ALTO - 44, tamano=16, color=cfg.GRIS)


# ---------------------------------------------------------------------------
# FINAL DEL JUEGO
#
# Dos partes sobre el mismo video (Corvo volando de regreso a su futuro, que
# ahora si tiene agua limpia):
#   1. La despedida, con unas lineas de texto.
#   2. Los creditos, que suben despacio.
# ---------------------------------------------------------------------------
DESPEDIDA = [
    "La planta cerró.",
    "El río empezó a correr limpio otra vez.",
    "",
    "Corvo se despidió y voló de regreso a su tiempo.",
    "",
    "Esta vez encontró un 2030 distinto:",
    "pueblos verdes, pozos llenos, agua para todos.",
    "",
    "El futuro no estaba escrito.",
    "Lo escribieron ustedes, cuidando cada gota.",
]

CREDITOS = [
    ("titulo", "BRIGADA 2030"),
    ("titulo", "EL POZO DEL TIEMPO"),
    ("", ""),
    ("seccion", "EQUIPO"),
    ("seccion", "CECYTEG TARANDACUAO"),
    ("", ""),
    ("seccion", "INTEGRANTES"),
    ("nombre", "Juan Ricardo García García"),
    ("nombre", "Gustavo Axel Aguilar Flores"),
    ("nombre", "Josué Yael García García"),
    ("nombre", "Renata Guerrero Bucio"),
    ("", ""),
    ("seccion", "ASESORA"),
    ("nombre", "Anel Monserrat Mendoza Medina"),
    ("", ""),
    ("seccion", "APOYO DE DISEÑOS"),
    ("nombre", "Cristian de Jesús Malagón Téllez"),
    ("nombre", "Enrique Hernández Sanabria"),
    ("", ""),
    ("seccion", "DOCENTE"),
    ("nombre", "José Israel Frías Guzmán"),
    ("", ""),
    ("", ""),
    ("seccion", "TecNM — CAMPUS IRAPUATO"),
    ("nombre", "Dr. Juan Pablo Serrano Rubio"),
    ("nombre", "M.E. Mariela Aguilar Almanza"),
    ("nombre", "M.T.I. César Manuel Hernández Mendoza"),
    ("nombre", "Dr. Jorge Noé García Chávez"),
    ("nombre", "Dr. Luis Enrique Raya González"),
    ("nombre", "M.E. Luz María Rodríguez Vidal"),
    ("nombre", "Dra. Akira Torreblanca Ponce"),
    ("nombre", "Lic. Cyanide Solorzano Hinojosa"),
    ("nombre", "Ing. Sergio Ismael Torres Sánchez"),
    ("", ""),
    ("", ""),
    ("seccion", "JAPAMI"),
    ("nombre", "Junta de Agua Potable, Alcantarillado"),
    ("nombre", "y Saneamiento del Municipio de Irapuato"),
    ("", ""),
    ("seccion", "DIRECTOR GENERAL"),
    ("nombre", "Ing. Ricardo Holguín Santana"),
    ("", ""),
    ("seccion", "ESTUDIANTES DE INGENIERÍA"),
    ("nombre", "María Guadalupe García Vaca"),
    ("nombre", "Fernando Esteban Molina Moreno"),
    ("nombre", "Alberto Alessandro Ríos Rodríguez"),
    ("nombre", "Dayeli Lizeth Ventura Vargas"),
    ("", ""),
    ("", ""),
    ("seccion", "GRACIAS POR EL APOYO"),
    ("titulo", "CECYTEG TARANDACUAO"),
    ("", ""),
    ("", ""),
    ("nombre", "Reto JAPAMI  ·  Track Talents 2026"),
    ("nombre", "Hecho con Python y Pygame"),
    ("", ""),
    ("seccion", "CUIDA EL AGUA"),
    ("nombre", "Cierra la llave. Repara las fugas."),
    ("nombre", "No tires basura al drenaje."),
    ("", ""),
    ("titulo", "FIN"),
]

ESTILO_CREDITOS = {
    "titulo": (46, (120, 220, 255), True),
    "seccion": (26, (120, 220, 60), True),
    "nombre": (24, (240, 240, 240), False),
    "": (20, (200, 200, 200), False),
}


class Final:
    DESPEDIDA_DURA = 660          # 11 segundos de despedida
    VELOCIDAD_CREDITOS = 1.15     # pixeles por cuadro (los creditos son largos)

    def __init__(self, personaje="aqua"):
        self.tiempo = 0
        self.personaje = personaje
        self.video = recursos.video("final", cfg.VIDEO_FINAL_FPS)
        self.desplazamiento = 0.0
        self.terminado = False
        # el final cierra con la misma pista del inicio
        recursos.musica("1_inicio", 0.5)

    @property
    def en_creditos(self):
        return self.tiempo > self.DESPEDIDA_DURA

    def tecla(self, tecla):
        if tecla in (pygame.K_SPACE, pygame.K_RETURN, pygame.K_KP_ENTER):
            if not self.en_creditos:
                # saltar la despedida y pasar directo a los creditos
                self.tiempo = self.DESPEDIDA_DURA + 1
                return None
            return "titulo"
        return None

    def actualizar(self):
        self.tiempo += 1
        self.video.actualizar(1.0 / cfg.FPS)
        if self.en_creditos:
            self.desplazamiento += self.VELOCIDAD_CREDITOS
            if self.desplazamiento > self._alto_total() + cfg.ALTO:
                return "titulo"
        return None

    @staticmethod
    def _alto_total():
        alto = 0
        for tipo, _texto in CREDITOS:
            alto += ESTILO_CREDITOS[tipo][0] + 16
        return alto

    def dibujar(self, pantalla):
        if not self.video.dibujar(pantalla):
            pantalla.fill((30, 60, 50))

        if not self.en_creditos:
            self._dibujar_despedida(pantalla)
        else:
            self._dibujar_creditos(pantalla)

        # oscurecido al arrancar, para empalmar con el nivel
        if self.tiempo < 60:
            velo = pygame.Surface((cfg.ANCHO, cfg.ALTO))
            velo.fill(cfg.NEGRO)
            velo.set_alpha(int(255 * (1 - self.tiempo / 60.0)))
            pantalla.blit(velo, (0, 0))

    def _dibujar_despedida(self, pantalla):
        # las lineas van apareciendo de una en una
        visibles = min(len(DESPEDIDA), 1 + self.tiempo // 55)
        alto = len(DESPEDIDA) * 34 + 56
        caja = pygame.Rect(255, cfg.ALTO // 2 - alto // 2, cfg.ANCHO - 510, alto)
        fondo = pygame.Surface(caja.size, pygame.SRCALPHA)
        fondo.fill((*cfg.NEGRO, 165))
        pantalla.blit(fondo, caja.topleft)

        for i, linea in enumerate(DESPEDIDA[:visibles]):
            color = cfg.AGUA if i in (3, 5) else cfg.BLANCO
            recursos.texto(pantalla, linea, cfg.ANCHO // 2,
                           caja.y + 25 + i * 34, tamano=23, color=color,
                           centrado=True)

        if self.tiempo > 120 and (self.tiempo // 30) % 2 == 0:
            recursos.texto(pantalla, "[TOCA] ver los créditos",
                           cfg.ANCHO // 2, cfg.ALTO - 48, tamano=17,
                           color=cfg.BLANCO, centrado=True)

    def _dibujar_creditos(self, pantalla):
        velo = pygame.Surface((cfg.ANCHO, cfg.ALTO), pygame.SRCALPHA)
        velo.fill((*cfg.NEGRO, 150))
        pantalla.blit(velo, (0, 0))

        y = cfg.ALTO - self.desplazamiento
        for tipo, linea in CREDITOS:
            tamano, color, negrita = ESTILO_CREDITOS[tipo]
            if linea and -60 < y < cfg.ALTO + 60:
                recursos.texto(pantalla, linea, cfg.ANCHO // 2, y,
                               tamano=tamano, color=color, centrado=True,
                               negrita=negrita)
            y += tamano + 16

        recursos.texto(pantalla, "[TOCA] volver al menú",
                       cfg.ANCHO // 2, cfg.ALTO - 42, tamano=16,
                       color=cfg.GRIS, centrado=True)
