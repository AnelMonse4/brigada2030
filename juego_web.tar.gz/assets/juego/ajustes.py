# -*- coding: utf-8 -*-
"""
Todos los numeros que se pueden tocar para cambiar como se siente el juego.
Si quieres que Aqua salte mas alto, que haya mas vidas, etc., se cambia AQUI.
"""
import os
import sys

# --- Carpetas ---------------------------------------------------------------
# Cuando el juego corre como .exe, PyInstaller descomprime todo en una carpeta
# temporal y la guarda en sys._MEIPASS. Si no, usamos la carpeta del proyecto.
if getattr(sys, "frozen", False):
    RAIZ = sys._MEIPASS
else:
    RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

ASSETS = os.path.join(RAIZ, "assets")

# --- Ventana ----------------------------------------------------------------
ANCHO = 1280
ALTO = 720
FPS = 60
TITULO = "Brigada 2030: El Pozo del Tiempo"

# Video de la pantalla de inicio (ver herramientas/preparar_imagenes.py)
VIDEO_FPS = 12
VIDEO_FINAL_FPS = 10           # el video de los creditos

# --- Colores ----------------------------------------------------------------
NEGRO = (12, 10, 18)
BLANCO = (245, 245, 245)
AGUA = (90, 190, 255)
VERDE_TOXICO = (120, 220, 60)
ROJO = (226, 48, 62)
GRIS = (150, 150, 165)
PANEL = (18, 26, 48)
BORDE = (90, 150, 210)

# --- Jugador ----------------------------------------------------------------
VIDAS = 5                      # los 5 corazones
VELOCIDAD = 4.2                # caminando
VELOCIDAD_CORRER = 7.0         # con SHIFT
VELOCIDAD_AGACHADO = 2.4       # agachado se avanza, pero despacio
FUERZA_SALTO = 15.0
SALTOS_MAXIMOS = 2             # 2 = doble salto (toca el boton otra vez en el aire)
FUERZA_SALTO_DOBLE = 12.5      # el segundo salto, un poco mas corto
GRAVEDAD = 0.62
CAIDA_MAXIMA = 18.0
INVULNERABLE = 90              # cuadros sin recibir dano tras un golpe (1.5 s)
ANCHO_JUGADOR = 46             # caja de colision (mas angosta que el dibujo)
ALTO_JUGADOR = 112
ALTO_AGACHADO = 72
ALZADO_EN_DIALOGO = 150        # cuanto sube la camara durante las escenas finales

# --- Ataque -----------------------------------------------------------------
RECARGA_DISPARO = 22           # cuadros entre disparo y disparo
VELOCIDAD_BOLA = 11.0
DANO_BOLA = 1
ALCANCE_BOLA = 620             # pixeles que viaja antes de desaparecer

# --- Enemigos ---------------------------------------------------------------
VIDA_ENEMIGO = 2               # golpes para tumbar un monstruo de basura
GOTAS_POR_ENEMIGO = 2          # gotas que suelta al caer
VELOCIDAD_HUIDA = 4.6          # que tan rapido huyen las personas del nivel 3
ESPERA_ATAQUE_ENEMIGO = (150, 260)   # cuadros entre ataque y ataque
ALCANCE_ATAQUE_ENEMIGO = 520   # a que distancia se animan a lanzar
VELOCIDAD_ENEMIGO = 1.5
VIDA_JEFE = 14
# --- Corvo, el jefe del nivel 1 ---------------------------------------------
# Si la pelea se siente MUY DIFICIL, lo que mas ayuda es subir CORVO_CANSANCIO
# (el rato que se queda agotado y sin poder lastimarte, que es cuando le pegas)
# y bajar CORVO_ALTURA (que tan arriba vuela: mientras mas bajo, mas facil
# alcanzarlo con la bola, que viaja recta).
VIDA_JEFE_CORVO = 8            # cuantos golpes aguanta
CORVO_ALTURA = 95              # que tan arriba de ti vuela, en pixeles
CORVO_AVISO = 46               # aviso antes de la picada (mas = mas facil)
CORVO_CANSANCIO = 110          # cuadros agotado tras la picada (ventana de ataque)
CORVO_DESCANSO = (80, 120)     # rato que flota entre ataque y ataque
# --- El empresario, jefe final del nivel 3 ----------------------------------
# Es el jefe FINAL: tiene que costar. Aguanta mas, se mueve mas rapido y
# ataca mas seguido que los otros dos.
VIDA_JEFE_FINAL = 26           # a la MITAD (13) se le cae la mascara
# Va un poco mas LENTO que el protagonista caminando (4.2), para que se
# pueda retroceder y tomar aire. Si fuera mas rapido te alcanzaria siempre
# y la pelea seria imposible: medido, nadie la ganaba.
VELOCIDAD_JEFE_FINAL = 3.2
ESCALA_JEFE_FINAL = 1.15
ESPERA_ATAQUE_JEFE_FINAL = (55, 95)    # cuadros entre ataque y ataque
DANO_JEFE_FINAL = 2            # tocarlo cuesta dos corazones

# El jefe de basura es LENTO a proposito: pesa, y el jugador debe poder
# correr mas rapido que el para salirse de su alcance.
VELOCIDAD_JEFE = 2.0
ALCANCE_LANZAMIENTO_JEFE = 4.6  # que tan lejos llega lo que tira (antes 7.0)
FUERZA_SALTO_JEFE = 15.0       # salta igual que el jugador, para poder seguirlo
ESCALA_JEFE = 1.9

# --- Nivel ------------------------------------------------------------------
SUELO_Y = 624                  # altura del piso
LARGO_NIVEL = 8200             # largo total del recorrido
DANO_PUAS = 1
# Los peligros fijos (puas, techos) se pueden romper a disparos y sueltan agua
VIDA_PELIGRO = 2               # disparos para romper una pua
GOTAS_POR_PELIGRO = 2          # gotas que deja al romperse
DANO_BOMBA = 1                 # el tanque verde que explota
DANO_OBSTACULO = 1             # botes toxicos, basura radiactiva, etc.
DANO_RIO = 1
DANO_ENEMIGO = 1
