# -*- coding: utf-8 -*-
"""
NIVEL 1 - EN BUSCA DEL AGUA

El pueblo lleva semanas sin agua en las tomas. El protagonista sale a buscar
agua para su familia: cruza el campo seco por andamios y puentes de madera
tendidos sobre el rio contaminado, recolectando cada gota que encuentra y
peleando con los monstruos de basura del camino.

Al final del recorrido esta el POZO, el ultimo que todavia tiene agua, y lo
custodia CORVO. Primero discuten (DIALOGO_ENCUENTRO) y luego pelean por el
agua. Cuando Corvo cae, explica quien es y de donde viene (DIALOGO_CORVO), y
los dos se teletransportan al futuro (nivel 2).

OJO: en este nivel Corvo NO acompana al protagonista. Se ve hasta el pozo, y
como enemigo. Eso lo controla CORVO_ACOMPANA = False.

El mapa lo genera herramientas/rearmar_nivel1.py, que mide el piso real de
cada dibujo y comprueba que todo se pueda cruzar.
"""
import math

import pygame

from . import ajustes as cfg
from . import recursos
from .nivel import NivelBase, Dialogo
from .entidades import Enemigo, JefeCorvo, Peligro


LARGO = 7400
RIO_Y = 600               # donde empieza el agua contaminada

# ---------------------------------------------------------------------------
# FONDO: una sola imagen (nivel1/fondo_nivel1.jpg), sin capas sueltas.
#
# Se mueve despacio (0.10) a proposito: la imagen mide 1971 px de ancho y el
# nivel 7400, asi que a esa velocidad alcanza a cubrir todo el recorrido de
# una sola pieza. Si se moviera mas rapido habria que repetirla, y la union
# se nota feisima.
# ---------------------------------------------------------------------------
VELOCIDAD_FONDO = 0.10
ALTURA_FONDO = -150       # cuanto se sube el fondo respecto a la ventana

# ---------------------------------------------------------------------------
# DATOS DEL MAPA (los escribe herramientas/rearmar_nivel1.py)
# ---------------------------------------------------------------------------
# PLATAFORMAS: (x, altura de la superficie, imagen).
# Generado por herramientas/rearmar_nivel1.py, que las coloca
# midiendo el piso REAL de cada dibujo.
PLATAFORMAS = [
    (0, 560, "puente_a"),
    (406, 530, "andamio_a"),
    (720, 560, "puente_b"),
    (1100, 500, "andamio_b"),
    (1398, 540, "puente_a"),
    (1804, 560, "andamio_a"),
    (2118, 510, "puente_b"),
    (2498, 560, "andamio_b"),
    (2796, 530, "puente_a"),
    (3202, 560, "andamio_a"),
    (3516, 500, "puente_b"),
    (3896, 540, "andamio_b"),
    (4194, 560, "puente_a"),
    (4600, 520, "andamio_a"),
    (4914, 560, "puente_b"),
    (5294, 540, "andamio_b"),
    (5592, 560, "puente_a"),
    (5998, 530, "andamio_a"),
    (6312, 560, "puente_b"),
    (6692, 560, "andamio_b"),
    (6700, 560, "puente_a"),
    (7030, 560, "puente_a"),
    (7360, 560, "puente_a"),
]

# PUAS: (x, imagen). La altura se saca de la plataforma de abajo.
PUAS = [
    (801, "pinchos_chicos"),
    (2881, "pinchos_caja"),
    (4995, "pinchos_chicos"),
]

# ADORNOS: (x, altura de la superficie, imagen, delante_del_jugador)
ADORNOS = [
    (22, 560, "caja_a", False),
    (741, 560, "caja_b", False),
    (1420, 540, "cerca", False),
    (2139, 510, "tronco_b", False),
    (2818, 530, "reciclaje_a", False),
    (3537, 500, "reciclaje_b", False),
    (4216, 560, "tronco_a", False),
    (4935, 560, "caja_a", False),
    (5614, 560, "caja_b", False),
    (6333, 560, "cerca", False),
    (900, 740, "mata_der", True),
    (2800, 740, "mata_izq", True),
    (4700, 740, "mata_der", True),
    (6600, 740, "mata_izq", True),
]

# FLOTANTES: (x, imagen). Basura en el rio contaminado.
FLOTANTES = [
    (260, "alga_a"),
    (880, "llanta_rama"),
    (1500, "alga_b"),
    (2120, "piedra"),
    (2740, "alga_c"),
    (3360, "alga_a"),
    (3980, "llanta_rama"),
    (4600, "alga_b"),
    (5220, "piedra"),
    (5840, "alga_c"),
    (6460, "alga_a"),
]

# ENEMIGOS: (x, limite izquierdo, limite derecho)
ENEMIGOS = [
    (1216, 1145, 1287),
    (2274, 2166, 2383),
    (3325, 3247, 3404),
    (4364, 4243, 4485),
    (5410, 5339, 5481),
    (6468, 6360, 6577),
]

# GOTAS: (x, y)
GOTAS = [
    (87, 502), (170, 502), (253, 502), (492, 472), (566, 472),
    (799, 502), (876, 502), (953, 502), (1181, 442), (1250, 442),
    (1485, 482), (1568, 482), (1651, 482), (1890, 502), (1964, 502),
    (2197, 452), (2274, 452), (2351, 452), (2579, 502), (2648, 502),
    (2883, 472), (2966, 472), (3049, 472), (3288, 502), (3362, 502),
    (3595, 442), (3672, 442), (3749, 442), (3977, 482), (4046, 482),
    (4281, 502), (4364, 502), (4447, 502), (4686, 462), (4760, 462),
    (4993, 502), (5070, 502), (5147, 502), (5375, 482), (5444, 482),
    (5679, 502), (5762, 502), (5845, 502), (6084, 472), (6158, 472),
    (6391, 502), (6468, 502), (6545, 502), (6773, 502), (6842, 502),
    (371, 380), (1065, 350), (1769, 390), (2463, 360), (3167, 380),
    (3861, 350), (4565, 370), (5259, 390), (5963, 380), (6657, 410),
]

# ---------------------------------------------------------------------------
# PELEA CONTRA CORVO
# ---------------------------------------------------------------------------
ARENA_IZQUIERDA = 6700
ARENA_DERECHA = LARGO - 60
POZO_X = 7150

DIALOGO_INICIO = (
    ("heroe", "", "Tercer día sin agua en la casa. Mi mamá ya no sabe qué hacer."),
    ("heroe", "", "Las tomas de la colonia llevan semanas secas."),
    ("heroe", "", "Mi hermanita tiene sed y yo no tengo nada que darle."),
    ("heroe", "", "Hasta el río que cruza el pueblo bajó podrido."),
    ("heroe", "", "Dicen que cruzando el campo todavía queda un pozo con agua."),
    ("heroe", "", "Si lleno aunque sea una botella, hoy sí tomamos todos."),
)

# Cuando llega al pozo y se topa con Corvo, ANTES de pelear.
DIALOGO_ENCUENTRO = (
    ("heroe", "", "Ahí está... el pozo. Y todavía tiene agua."),
    ("corvo", "CORVO", "Alto ahí. No des un paso más hacia ese pozo."),
    ("heroe", "", "¿Un cuervo... hablando?"),
    ("corvo", "CORVO", "Ese pozo no está para llenar botellas. Da media vuelta."),
    ("heroe", "", "Mi familia lleva tres días sin agua. No me voy a ir."),
    ("heroe", "", "Hice todo este camino por ellos."),
    ("corvo", "CORVO", "Y yo llevo más tiempo del que crees cuidando esta agua."),
    ("corvo", "CORVO", "No puedo dejar que te la lleves. No así."),
    ("heroe", "", "Entonces vamos a tener que pelear por ella."),
    ("corvo", "CORVO", "Eso parece. Veamos cuánto aguantas."),
)

DIALOGO_CORVO = (
    ("corvo", "CORVO", "Espera... baja los puños. Ya entendí."),
    ("corvo", "CORVO", "Peleaste así por tu familia, no por ganarme."),
    ("corvo", "CORVO", "Me llamo Corvo. No soy un animal de este tiempo."),
    ("corvo", "CORVO", "Soy un cuervo de agua, y vengo del año 2030."),
    ("heroe", "", "¿Del futuro? ¿Y por qué cuidabas tanto este pozo?"),
    ("corvo", "CORVO", "Porque es lo último que conecta los dos tiempos."),
    ("corvo", "CORVO", "En mi época no queda agua limpia. Ni una gota."),
    ("corvo", "CORVO", "Hay miles de familias como la tuya, pero ya sin pozo."),
    ("heroe", "", "Entonces no me atacabas... me estabas probando."),
    ("corvo", "CORVO", "Necesitaba saber si aguantarías lo que te voy a enseñar."),
    ("corvo", "CORVO", "Llévate el agua para los tuyos. Te lo ganaste."),
    ("corvo", "CORVO", "Pero antes ven conmigo. Tienes que verlo con tus ojos."),
    ("corvo", "CORVO", "Sujétate fuerte. El pozo nos va a llevar al 2030."),
)


class Nivel1(NivelBase):
    MUSICA = "1_inicio"
    ROTULO = "NIVEL 1  ·  EN BUSCA DEL AGUA"
    LARGO = LARGO
    SUELO_Y = 560
    INICIO_X = 120
    DIALOGO_INICIO = DIALOGO_INICIO
    # Corvo no acompana en este nivel: aparece hasta el pozo, como enemigo.
    CORVO_ACOMPANA = False

    # -- construccion del mapa ------------------------------------------
    def construir(self):
        self.piso = []
        for x, y, nombre in PLATAFORMAS:
            img = recursos.imagen("nivel1", nombre)
            self.piso.append((x, y, img))
            self.solidos.append(recursos.caja_de_piso("nivel1", nombre, x, y, 300))
            self.puntos_seguros.append(x + 60)

        for x, nombre in PUAS:
            img = recursos.imagen("nivel1", nombre)
            ancho, alto = img.get_size()
            y = self.superficie(x) - alto + 6
            # la caja de dano es mas angosta que el dibujo: rozar la orilla
            # no castiga
            caja = pygame.Rect(x + 24, y + alto // 2, ancho - 48, alto // 2)
            self.peligros.append(Peligro(caja, img, x, y))

        for x, y, nombre, delante in ADORNOS:
            img = recursos.imagen("nivel1", nombre)
            destino = self.adornos_frente if delante else self.adornos_atras
            destino.append((x, y - img.get_height() + 8, img))

        for x, nombre in FLOTANTES:
            img = recursos.imagen("nivel1", nombre)
            self.adornos_frente.append((x, RIO_Y + 40, img))

        # el rio contaminado corre por todo el nivel, por debajo de las tablas
        self.agua.append((pygame.Rect(0, RIO_Y + 34, LARGO, 300), None))

        self.img_fondo = recursos.imagen("nivel1", "fondo")
        self.img_pozo = recursos.imagen("nivel", "pozo")

        self.puntos_seguros = sorted(set(self.puntos_seguros))

        self.jefe_aparecio = False
        self.presentacion = False
        self.brillo_pozo = 0.0
        self.escena = 0
        self.reloj_escena = 0
        self.destello = 0.0

    @staticmethod
    def superficie(x):
        """Altura de la plataforma que hay debajo de esa posicion."""
        for px, py, nombre in PLATAFORMAS:
            izq, der = recursos.borde_pisable("nivel1", nombre)
            if px + izq <= x <= px + der:
                return py
        return 560

    def crear_enemigos(self):
        return [Enemigo(x, self.superficie(x), izq, der)
                for x, izq, der in ENEMIGOS]

    def lista_gotas(self):
        return GOTAS

    # -- el jefe --------------------------------------------------------
    def revisar_jefe(self):
        # OJO: aqui NO se puede cortar con "si ya hay jefe, salir". Durante el
        # dialogo del encuentro el jefe ya existe pero todavia esta dormido,
        # y es justo despues de ese dialogo cuando hay que despertarlo.
        if self.jefe_aparecio:
            return
        if self.jugador.rect.centerx <= ARENA_IZQUIERDA:
            return

        if not self.presentacion:
            # Primero se encuentran y discuten. Corvo ya se ve en pantalla,
            # pero quieto: mientras hay dialogo el juego no actualiza a nadie.
            self.presentacion = True
            self.jefe = JefeCorvo(ARENA_IZQUIERDA + 420, 330,
                                  ARENA_IZQUIERDA + 60, ARENA_DERECHA - 60,
                                  170, self.SUELO_Y - 90)
            self.jefe.despierto = False
            self.dialogo = Dialogo(DIALOGO_ENCUENTRO, self.personaje)
            self.jugador.vx = 0.0
            self.jugador.mirando = 1
            return

        # el dialogo termino: se descarta para que no bloquee nada despues
        self.dialogo = None
        self.jefe_aparecio = True
        self.jefe.despierto = True
        self.temblor = 36
        self.aviso = ["¡POR EL AGUA!", 150]

    def al_vencer_jefe(self):
        """Corvo cae: empieza la explicación y después el teletransporte."""
        self.temblor = 40
        self.aviso = None          # que no quede el letrero de la pelea
        self.proyectiles.clear()
        self.bolas.clear()
        self.cerrar_dialogos()
        self.jugador.intocable = True
        self.jugador.invulnerable = 0
        if not self.jugador.en_suelo or self.jugador.rect.top > cfg.ALTO:
            self.plantar_en_suelo(self.jugador)
        self.cinematica = "final"
        self.escena = 0
        self.reloj_escena = 70

    # -- la escena final -------------------------------------------------
    def actualizar_cinematica(self):
        self.jugador.actualizar(self)
        if self.jefe and self.escena <= 1:
            # sigue cayendo y despues se queda tirado en el piso
            self.jefe.actualizar(self, self.jugador)
        if self.temblor > 0:
            self.temblor -= 1

        # ESCENA 0: Corvo termina de caer
        if self.escena == 0:
            self.reloj_escena -= 1
            if self.reloj_escena <= 0:
                self.escena = 1
                self.dialogo_final = Dialogo(DIALOGO_CORVO, self.personaje)

        # ESCENA 1: Corvo sigue TIRADO en el piso y da su explicación.
        # No desaparece: se queda ahi, caido, mientras habla.
        elif self.escena == 1:
            self.dialogo_final.actualizar()
            if not self.dialogo_final.activo:
                self.escena = 2
                self.reloj_escena = 0

        # ESCENA 2: Corvo SE LEVANTA del piso y se pone a volar.
        # Sube despacio desde donde cayo hasta su altura de vuelo, y recien
        # ahi deja de ser el jefe y pasa a ser el acompañante.
        elif self.escena == 2:
            self.reloj_escena += 1
            if self.jefe is not None:
                self.jefe.poner("volar")
                self.jefe.y -= 2.2
                self.jefe.x += (self.jugador.rect.centerx + 120 - self.jefe.x) * 0.04
                self.jefe.rect.center = (int(self.jefe.x), int(self.jefe.y))
                self.jefe.animacion.actualizar()
                if self.reloj_escena > 55:
                    self.corvo.escondido = False
                    self.corvo.colocar(self.jefe.rect.centerx,
                                       self.jefe.rect.centery)
                    self.jefe = None
                    self.escena = 3
                    self.reloj_escena = 0

        # ESCENA 3: los dos caminan al pozo y este empieza a brillar
        elif self.escena == 3:
            self.reloj_escena += 1
            self.brillo_pozo = min(1.0, self.reloj_escena / 110.0)
            llego = self.caminar_hasta(POZO_X - 40)
            self.corvo.actualizar(self.jugador)
            if self.brillo_pozo >= 1.0 and llego:
                self.escena = 4
                self.reloj_escena = 0

        # ESCENA 4: el protagonista y Corvo brillan y desaparecen
        elif self.escena == 4:
            self.reloj_escena += 1
            self.corvo.actualizar(self.jugador)
            self.destello = min(1.0, self.reloj_escena / 95.0)
            if self.reloj_escena > 95:
                self.fundido += 7
                if self.fundido >= 255:
                    self.terminado = True
                    self.resultado = "ganado"

        self.mover_camara()

    # -- dibujo ----------------------------------------------------------
    def dibujar_fondo(self, pantalla, cx, cy):
        pantalla.fill((214, 176, 112))
        pantalla.blit(self.img_fondo,
                      (-int(cx * VELOCIDAD_FONDO),
                       ALTURA_FONDO - int(cy * 0.2)))

    def dibujar_terreno(self, pantalla, cx, cy):
        # EL RIO CONTAMINADO.
        # Se dibuja a mano y no se deja al fondo, porque en el fondo esa
        # franja se ve como tierra seca y el jugador creeria que puede
        # caminar ahi. Tiene que leerse claro que es agua y que mata.
        self._dibujar_rio(pantalla, cx, cy)

        for x, y, img in self.piso:
            if -700 < x - cx < cfg.ANCHO + 700:
                pantalla.blit(img, (x - cx, y - cy))

        # el pozo del final, por detrás de los personajes
        if self.brillo_pozo > 0:
            self._halo(pantalla, POZO_X - cx,
                       self.SUELO_Y - self.img_pozo.get_height() // 2 - cy,
                       210 * self.brillo_pozo, self.brillo_pozo)
        pantalla.blit(self.img_pozo,
                      (POZO_X - self.img_pozo.get_width() // 2 - cx,
                       self.SUELO_Y - self.img_pozo.get_height() + 10 - cy))

    def dibujar_extra(self, pantalla, cx, cy):
        if self.destello > 0:
            self._brillar(pantalla, self.jugador.rect, cx, cy, self.destello)
            self._brillar(pantalla, self.corvo.rect, cx, cy, self.destello)
            if self.destello > 0.6:
                velo = pygame.Surface((cfg.ANCHO, cfg.ALTO))
                velo.fill((235, 250, 255))
                velo.set_alpha(int(255 * (self.destello - 0.6) / 0.4))
                pantalla.blit(velo, (0, 0))

    @staticmethod
    def _dibujar_rio(pantalla, cx, cy):
        arriba = RIO_Y - cy
        agua = pygame.Rect(0, arriba, cfg.ANCHO, cfg.ALTO - arriba + 200)
        pygame.draw.rect(pantalla, (58, 92, 52), agua)

        # vetas mas claras, como corriente
        tiempo = pygame.time.get_ticks() * 0.0012
        for i in range(4):
            y = arriba + 26 + i * 34
            tono = (86 - i * 8, 124 - i * 10, 70 - i * 6)
            paso = 150
            desfase = int((tiempo * (30 + i * 14) - cx * 0.6)) % paso
            for x in range(-paso + desfase, cfg.ANCHO + paso, paso):
                pygame.draw.line(pantalla, tono, (x, y), (x + 70, y), 3)

        # la orilla: una linea de espuma sucia que ondula
        puntos = []
        for x in range(0, cfg.ANCHO + 10, 10):
            onda = 4 * math.sin((x + cx) * 0.02 + tiempo * 2)
            puntos.append((x, arriba + onda))
        if len(puntos) > 1:
            pygame.draw.lines(pantalla, (132, 168, 96), False, puntos, 4)
            pygame.draw.lines(pantalla, (176, 200, 128), False,
                              [(x, y - 4) for x, y in puntos], 2)

    # NOTA: al dibujar con BLEND_RGBA_ADD, pygame SUMA el color y no hace caso
    # del alfa. Si se pinta un circulo de (150,225,255) con alfa bajo, igual
    # sale un disco blanco solido. Por eso aqui el color ya viene "apagado"
    # segun la intensidad que queremos: asi si se logra un degradado suave.
    @staticmethod
    def _halo(pantalla, x, y, radio, fuerza):
        radio = max(4, int(radio))
        capas = 14
        halo = pygame.Surface((radio * 2, radio * 2), pygame.SRCALPHA)
        for i in range(capas):
            r = int(radio * (1 - i / float(capas)))
            s = 0.105 * fuerza
            color = (int(150 * s), int(225 * s), int(255 * s), 255)
            pygame.draw.circle(halo, color, (radio, radio), max(1, r))
        pantalla.blit(halo, (int(x - radio), int(y - radio)),
                      special_flags=pygame.BLEND_RGBA_ADD)

    @staticmethod
    def _brillar(pantalla, rect, cx, cy, fuerza):
        ancho = rect.width + 80
        alto = rect.height + 80
        capas = 10
        halo = pygame.Surface((ancho, alto), pygame.SRCALPHA)
        for i in range(capas):
            caja = halo.get_rect().inflate(-i * (ancho // (capas * 2)),
                                           -i * (alto // (capas * 2)))
            s = 0.13 * fuerza
            color = (int(210 * s), int(245 * s), int(255 * s), 255)
            pygame.draw.ellipse(halo, color, caja)
        pantalla.blit(halo, (rect.centerx - ancho // 2 - cx,
                             rect.centery - alto // 2 - cy),
                      special_flags=pygame.BLEND_RGBA_ADD)
